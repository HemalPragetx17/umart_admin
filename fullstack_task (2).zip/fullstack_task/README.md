# Airtable Integration - Fullstack Application

Complete fullstack application for Airtable integration with OAuth authentication, built with Angular 19 and Node.js.

## 📋 Stack

### Frontend
- Angular 19
- AG Grid Community & AG Charts (v33.0)
- Angular Material
- Material Icons
- TypeScript
- SCSS

### Backend
- Node.js v22
- Express.js
- MongoDB with Mongoose
- Airtable.js
- OAuth 2.0

## 🚀 Quick Start

### Prerequisites
- Node.js v22 or higher
- MongoDB installed and running
- Airtable account with OAuth app credentials

### Backend Setup

1. Navigate to backend folder:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Create `.env` file from example:
```bash
copy .env.example .env
```

4. Configure `.env` with your credentials:
   - Get Airtable OAuth credentials from: https://airtable.com/create/oauth
   - Set MongoDB connection string
   - Configure session secret

5. Start the backend server:
```bash
npm run dev
```

Backend will run on `http://localhost:3000`

### Frontend Setup

1. Navigate to frontend folder:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

Frontend will run on `http://localhost:4200`

## 📁 Project Structure

```
fullstack_task/
├── backend/
│   ├── src/
│   │   ├── config/          # Database & Airtable configuration
│   │   ├── controllers/     # Request handlers
│   │   ├── middleware/      # Auth middleware
│   │   ├── models/          # MongoDB models
│   │   ├── routes/          # API routes
│   │   └── server.js        # Main server file
│   ├── package.json
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── app/
    │   │   ├── core/        # Services, guards, interceptors
    │   │   └── features/    # Components (login, dashboard)
    │   ├── environments/    # Environment configs
    │   └── styles.scss
    ├── angular.json
    └── package.json
```

## 🔐 OAuth Flow

1. User clicks "Connect with Airtable"
2. Frontend requests auth URL from backend
3. User is redirected to Airtable authorization page
4. User authorizes the application
5. Airtable redirects back to backend callback
6. Backend exchanges code for access token
7. Token is stored in MongoDB
8. User is redirected to frontend dashboard

## 📊 Features

### Airtable Integration
- ✅ OAuth 2.0 authentication
- ✅ Fetch bases (projects) - `/meta/bases`
- ✅ Fetch tables - `/meta/bases/${baseId}/tables`
- ✅ Fetch records (tickets/pages) - `/${baseId}/${tableId}`
- ✅ Pagination support for large datasets
- ✅ Store all records in MongoDB
- ✅ Bulk sync functionality

### Frontend Features
- ✅ Material Design UI
- ✅ AG Grid for data visualization
- ✅ Dynamic column generation
- ✅ Sorting and filtering
- ✅ Pagination
- ✅ Responsive design
- ✅ Protected routes with guards

### Backend Features
- ✅ RESTful API
- ✅ Session-based authentication
- ✅ MongoDB integration
- ✅ Token management
- ✅ Error handling
- ✅ CORS configuration

## 🔌 API Endpoints

### Authentication
- `GET /api/auth/login` - Get OAuth URL
- `GET /api/auth/callback` - OAuth callback
- `POST /api/auth/logout` - Logout
- `GET /api/auth/status` - Check auth status

### Airtable (Protected)
- `GET /api/airtable/bases` - List all bases
- `GET /api/airtable/bases/:baseId/tables` - List tables
- `GET /api/airtable/bases/:baseId/tables/:tableId/records` - List records
- `POST /api/airtable/sync` - Sync all data to MongoDB
- `GET /api/airtable/users` - Get user info

## 📝 Environment Variables

### Backend (.env)
```
PORT=3000
MONGODB_URI=mongodb://localhost:27017/airtable_integration
AIRTABLE_CLIENT_ID=your_client_id
AIRTABLE_CLIENT_SECRET=your_client_secret
AIRTABLE_REDIRECT_URI=http://localhost:3000/api/auth/callback
SESSION_SECRET=your_session_secret
FRONTEND_URL=http://localhost:4200
```

### Frontend
Update `src/environments/environment.ts`:
```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api'
};
```

## 🛠️ Development

### Backend Development
```bash
cd backend
npm run dev  # Runs with nodemon for auto-reload
```

### Frontend Development
```bash
cd frontend
npm start    # Runs on port 4200
```

## 📦 Building for Production

### Backend
```bash
cd backend
npm start
```

### Frontend
```bash
cd frontend
npm run build
# Build artifacts will be in dist/
```

## 🗄️ MongoDB Collections

### tokens
Stores OAuth access tokens and refresh tokens:
- userId
- accessToken
- refreshToken
- expiresAt
- scopes

### pages
Stores synced Airtable records:
- airtableId
- baseId
- tableId
- fields (all record data)
- createdTime

## 🔍 Key Implementation Details

### Pagination
The application implements Airtable API pagination:
- Uses `offset` parameter for pagination
- Default page size: 100 records
- Continues fetching until no offset is returned

### Token Management
- Tokens stored securely in MongoDB
- Automatic expiration checking
- Session-based authentication

### Data Sync
- Bulk operations for efficiency
- Upsert strategy to avoid duplicates
- Syncs entire tables to MongoDB

## 📄 License

ISC

## 👤 Author

Your Name

## 🤝 Contributing

Contributions welcome! Please feel free to submit a Pull Request.
