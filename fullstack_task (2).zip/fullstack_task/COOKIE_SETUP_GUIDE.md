now cokkie# Cookie Setup Guide for Revision History Scraping

## Overview
This guide explains how to set up Airtable cookies to enable revision history scraping functionality.

## Why Do I Need Cookies?
To fetch revision history from Airtable, the application needs authenticated access to your Airtable account. Cookies provide this authentication without storing your password.

---

## Setup Options

### Option 1: Paste Browser Cookies (Recommended - Quick & Easy)

#### Step-by-Step Instructions:

1. **Login to Airtable**
   - Open [airtable.com](https://airtable.com) in your browser
   - Log in to your account

2. **Open Developer Tools**
   - Press `F12` (or `Ctrl+Shift+I` on Windows, `Cmd+Option+I` on Mac)
   - The Developer Tools panel will open

3. **Navigate to Cookies**
   - Click on the **Application** tab (or **Storage** in Firefox)
   - In the left sidebar, expand **Cookies**
   - Click on **https://airtable.com**

4. **Copy Cookie Values**
   - You'll see a list of cookies with Name and Value columns
   - Look for important cookies like:
     - `brw_session`
     - `session_id`
     - `user_token`
   - Copy the entire cookie string in this format:
     ```
     name1=value1; name2=value2; name3=value3
     ```

5. **Paste in Application**
   - Go to the Cookie Setup panel in the dashboard
   - Enter a unique **User ID** (e.g., your email or `user123`)
   - Paste the cookie string in the **Cookie String** field
   - Click **Save Cookies**

#### Example Cookie Format:
```
brw_session=abc123xyz456; session_id=def789uvw012; user_token=ghi345rst678; _airtable_session=jkl901mno234
```

---

### Option 2: Login with Airtable Credentials

#### When to Use This Option:
- You prefer automatic cookie retrieval
- You don't want to manually copy cookies
- You have MFA (Multi-Factor Authentication) enabled

#### Step-by-Step Instructions:

1. **Enter User ID**
   - Enter a unique identifier (e.g., `user123` or your email)

2. **Enter Airtable Credentials**
   - **Email**: Your Airtable account email address
   - **Password**: Your Airtable account password

3. **MFA Code (If Enabled)**
   - If you have Two-Factor Authentication enabled:
   - Open your authenticator app (Google Authenticator, Authy, etc.)
   - Enter the 6-digit code in the **MFA Code** field

4. **Save Cookies**
   - Click **Save Cookies**
   - The system will automatically login and retrieve cookies
   - Your credentials are **NOT stored** - only the cookies

#### Security Note:
🔒 Your credentials are used only to fetch cookies and are **NOT stored permanently** in the database.

---

## Validating Cookies

After saving cookies, you should validate them to ensure they work:

1. Click the **Validate Cookies** button
2. The system will test the cookies against Airtable's API
3. You'll see one of these messages:
   - ✅ **Success!** - Cookies are valid and working
   - ❌ **Failed** - Cookies are invalid or expired

### Common Validation Errors:

| Error Message | Solution |
|--------------|----------|
| "Invalid cookies" | Re-copy cookies from browser or login again |
| "Cookies expired" | Cookies expire after 30 days - refresh them |
| "No cookies found" | You need to save cookies first |
| "User ID is required" | Enter a User ID before validating |

---

## Cookie Expiration

- **Expiry Period**: Cookies expire after **30 days**
- **Auto-Check**: The system tracks the last validation date
- **Refresh Needed**: When cookies expire, you'll need to repeat the setup process

---

## Troubleshooting

### Problem: "Please login first" error
**Solution**: You haven't authenticated with the main application. Login first, then set up cookies.

### Problem: Revision history fetch fails
**Solution**: 
1. Validate your cookies
2. If invalid, re-setup cookies
3. Make sure you have access to the base/table in Airtable

### Problem: Cookies work initially but fail after a few days
**Solution**: Airtable may have logged you out. Re-copy cookies or login again.

### Problem: MFA code not working
**Solution**:
- Make sure you're entering the current 6-digit code
- The code expires every 30 seconds - enter it quickly
- Verify you're using the correct authenticator app

---

## Best Practices

1. **Use a Consistent User ID**
   - Use the same User ID across sessions
   - Recommended: Use your email address

2. **Validate After Setup**
   - Always click "Validate Cookies" after saving
   - This confirms cookies are working

3. **Refresh Before Expiry**
   - Set a reminder to refresh cookies every 25 days
   - Don't wait for them to expire

4. **Keep Cookies Secure**
   - Don't share your cookie strings
   - They provide full access to your Airtable account

5. **Clear Form When Done**
   - Use "Clear Form" button to remove sensitive data
   - Cookies are safely stored in the database

---

## Quick Reference

### Required Fields:
- ✅ **User ID** (always required)
- ✅ **Cookie String** OR **Email + Password**
- ⚪ **MFA Code** (only if you have 2FA enabled)

### Button Functions:
- 🔵 **Save Cookies** - Store cookies in database
- 🟢 **Validate Cookies** - Test if cookies work
- ⚪ **Clear Form** - Reset all fields

### Status Indicators:
- 🟢 Green box = Success
- 🔴 Red box = Error
- 🔵 Blue box = Information

---

## Example Workflow

1. Open **Cookie Setup** panel
2. Enter User ID: `john.doe@company.com`
3. Choose one method:
   - **Method A**: Paste cookies from browser
   - **Method B**: Enter email/password (+ MFA if enabled)
4. Click **Save Cookies**
5. Wait for "Cookies saved successfully" message
6. Click **Validate Cookies**
7. See "Cookies are valid and working!" message
8. Click **Clear Form** to remove sensitive data
9. Close the panel - you're ready to fetch revision history!

---

## Support

If you encounter issues not covered in this guide:
1. Check the browser console for detailed error messages
2. Verify you have proper access to Airtable bases/tables
3. Try logging out and back into Airtable
4. Contact your system administrator

---

**Last Updated**: November 15, 2025
