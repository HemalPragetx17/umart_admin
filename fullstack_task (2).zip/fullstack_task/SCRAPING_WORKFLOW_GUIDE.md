# Revision History Scraping - Complete Workflow Guide

## Overview
This guide walks you through the complete process of scraping revision history from Airtable, from setup to viewing results.

---

## Prerequisites

✅ **Before you start, make sure you have:**
1. A valid Airtable account with access to at least one base
2. Authentication completed (logged into the dashboard)
3. Access to bases/tables you want to scrape

---

## Step-by-Step Workflow

### Step 1: Login to the Application

1. Navigate to the login page
2. Click "Login with Airtable"
3. Complete OAuth authentication
4. You'll be redirected to the dashboard

---

### Step 2: Set Up Cookies (One-Time Setup)

**Why?** Cookies are required to authenticate scraping requests to Airtable's internal APIs.

1. Click the **"Cookie Setup"** button in the top-right corner
2. Enter a **User ID** (e.g., `user123` or your email)
3. Choose one of two methods:

#### Method A: Browser Cookies (Recommended)
- Open [airtable.com](https://airtable.com) and login
- Press F12 → Application → Cookies → https://airtable.com
- Copy the cookie string
- Paste it in the "Cookie String" field

#### Method B: Login with Credentials
- Enter your Airtable email and password
- If you have MFA enabled, enter the 6-digit code
- Click "Save Cookies"

4. Click **"Validate Cookies"** to confirm they work
5. Wait for the green success message
6. Close the cookie panel (or leave it open)

**Note:** Cookies expire after 30 days. You'll need to refresh them when they expire.

---

### Step 3: Select Base and Table

1. **Select a Base (Project)**
   - Use the dropdown to select your Airtable base
   - Wait for tables to load

2. **Select a Table**
   - Choose a table from the dropdown
   - **IMPORTANT:** Wait for records to load in the grid below
   - You'll see a loading spinner, then records will appear

**Why wait?** Records must be synced to MongoDB before scraping can begin. This happens automatically when you select a table.

---

### Step 4: Verify Records are Loaded

Before scraping, confirm:
- ✅ Records appear in the grid below
- ✅ You see "Records (X)" in the header
- ✅ The grid shows your data

**If no records appear:**
- Wait a few more seconds
- Check your internet connection
- Verify you have access to this table in Airtable
- Try selecting a different table

---

### Step 5: Start Scraping Revision History

1. Click the **"Fetch Revision History"** button (purple/accent color)
2. Wait for the scraping process to complete
   - You'll see a spinner and "Scraping in progress..." message
   - This can take several minutes depending on the number of records
   - The process runs in batches of 10 records with 1-second delays

3. View the results:
   - **Total Records:** Number of records processed
   - **Successful:** Records with revision history successfully scraped
   - **Failed:** Records that encountered errors

---

### Step 6: Understanding Results

#### Success Scenario ✅
```
Scraping Results
Total Records: 50
Successful: 48
Failed: 2
```

- Revision history is now stored in MongoDB
- You can query it via the API endpoint: `GET /api/scraping/revision-history/record/{recordId}`

#### Partial Success ⚠️
```
Scraping Results
Total Records: 50
Successful: 25
Failed: 25

Errors:
- Record rec123: Cookies expired or invalid
- Record rec456: Failed to fetch revision history
```

**What to do:**
- Check the error messages
- If cookies are expired, refresh them (Step 2)
- Some records may not have revision history

#### Failure Scenario ❌
```
Error: No records found in database
```

**Solution:** Records weren't synced. Go back to Step 3 and wait for records to load.

---

## Common Issues & Solutions

### Issue: "No records found in database"
**Cause:** Table data hasn't been synced to MongoDB yet  
**Solution:** 
1. Make sure you selected a table
2. Wait for records to appear in the grid
3. Try clicking the table dropdown again to re-load

### Issue: "Invalid or missing cookies"
**Cause:** Cookies not set or expired  
**Solution:**
1. Click "Cookie Setup"
2. Follow Step 2 to set up cookies
3. Click "Validate Cookies" to confirm

### Issue: "Scraping completed but no records were successfully processed"
**Cause:** Multiple possible reasons  
**Solution:**
1. Check browser console for detailed errors
2. Validate your cookies
3. Verify you have access to the base/table in Airtable
4. Check if the table has any revision history

### Issue: Button is disabled
**Causes and Solutions:**

| Reason | How to Fix |
|--------|-----------|
| No User ID | Enter User ID in Cookie Setup |
| No Cookies | Set up cookies (Step 2) |
| No Table Selected | Select a base and table |
| No Records Loaded | Wait for records to appear in grid |
| Currently Scraping | Wait for current operation to complete |

### Issue: High failure rate
**Possible Causes:**
- Cookies expired during scraping (long process)
- Network issues
- Some records don't have revision history
- Rate limiting from Airtable

**Solutions:**
1. Refresh cookies before large scraping jobs
2. Try scraping in smaller batches
3. Check network connection
4. Review error details in the results

---

## Technical Details

### What Gets Scraped?
The scraper focuses on:
- ✅ **Assignee changes** (who was assigned → who is assigned now)
- ✅ **Status changes** (status was → status is now)
- ✅ **Timestamps** (when changes occurred)
- ✅ **User attribution** (who made the change)

### Processing Details
- **Batch Size:** 10 records at a time
- **Delay:** 1 second between batches
- **Limit:** Up to 200 records per scraping job
- **Storage:** Results stored in MongoDB `RevisionHistory` collection

### API Endpoint Used
```
GET https://airtable.com/{baseId}/{tableId}/{recordId}/readRowActivitiesAndComments
```

This is an internal Airtable endpoint (not part of official API), which is why cookies are needed.

---

## Best Practices

### 1. Prepare Before Scraping
- ✅ Set up and validate cookies first
- ✅ Test with a small table before large ones
- ✅ Ensure stable internet connection

### 2. Monitor Progress
- ✅ Watch the progress indicator
- ✅ Check console for detailed logs
- ✅ Note any error patterns

### 3. Cookie Management
- ✅ Validate cookies before large jobs
- ✅ Refresh cookies every 25 days
- ✅ Use consistent User ID

### 4. Handle Errors Gracefully
- ✅ Review error messages
- ✅ Don't retry immediately on failure
- ✅ Check Airtable access permissions

### 5. Data Verification
- ✅ Spot-check scraped data
- ✅ Compare with Airtable UI
- ✅ Verify timestamps are correct

---

## Example Workflow Timeline

```
0:00 - Login to application
0:30 - Click "Cookie Setup"
0:45 - Paste cookies from browser
1:00 - Click "Save Cookies"
1:05 - Click "Validate Cookies" → ✅ Success
1:10 - Select Base: "My Project"
1:15 - Select Table: "Tasks"
1:20 - Wait for records to load... (50 records loaded)
1:30 - Click "Fetch Revision History"
1:35 - Scraping in progress... (batch 1/5)
2:00 - Scraping in progress... (batch 3/5)
2:30 - Scraping in progress... (batch 5/5)
2:45 - ✅ Scraping completed! Successful: 48, Failed: 2
2:50 - Review results and error details
```

**Total Time:** ~3 minutes for 50 records

---

## Troubleshooting Checklist

Before asking for help, verify:

- [ ] I'm logged into the application
- [ ] I've set up cookies (User ID entered)
- [ ] I've validated cookies (green success message)
- [ ] I've selected a base and table
- [ ] Records are visible in the grid below
- [ ] I've waited for the scraping to complete
- [ ] I've checked the browser console for errors
- [ ] I've checked the backend logs (if accessible)

---

## Advanced: Viewing Scraped Data

### Via API
```bash
GET /api/scraping/revision-history/record/{recordId}
```

**Response:**
```json
{
  "airtableRecordId": "rec123456",
  "baseId": "appABC123",
  "tableId": "tblDEF456",
  "changes": [
    {
      "timestamp": "2025-11-10T14:30:00Z",
      "user": "John Doe",
      "changeType": "assignee",
      "field": "Assignee",
      "oldValue": "Jane Smith",
      "newValue": "John Doe"
    },
    {
      "timestamp": "2025-11-12T09:15:00Z",
      "user": "Jane Smith",
      "changeType": "status",
      "field": "Status",
      "oldValue": "In Progress",
      "newValue": "Done"
    }
  ],
  "lastScraped": "2025-11-15T12:00:00Z"
}
```

### Via MongoDB
```javascript
db.revisionhistories.find({ baseId: "appABC123", tableId: "tblDEF456" })
```

---

## Performance Expectations

| Records | Estimated Time | Notes |
|---------|---------------|-------|
| 10 | 15-30 seconds | Fast |
| 50 | 1-2 minutes | Normal |
| 100 | 2-4 minutes | Moderate |
| 200 | 4-8 minutes | Maximum limit |

**Factors affecting speed:**
- Network latency
- Airtable server response time
- Amount of revision history per record
- Current server load

---

## Support & Next Steps

### If You're Still Having Issues:

1. **Check Backend Logs**
   ```bash
   cd backend
   npm start
   # Watch console output
   ```

2. **Check Browser Console**
   - Press F12
   - Go to Console tab
   - Look for error messages in red

3. **Enable Debug Mode**
   - Open browser console
   - Look for logs starting with "Starting bulk scraping..."

4. **Contact Support**
   - Provide error messages
   - Share scraping results screenshot
   - Mention User ID used
   - Specify base/table names

---

## Security Notes

🔒 **Remember:**
- Cookies provide full access to your Airtable account
- Don't share cookies with others
- Refresh cookies regularly
- Use HTTPS only
- Logout when done on shared computers

---

**Last Updated:** November 15, 2025  
**Version:** 1.0
