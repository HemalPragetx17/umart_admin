// Load environment variables first
import './env.js';

export const airtableConfig = {
  clientId: process.env.AIRTABLE_CLIENT_ID,
  clientSecret: process.env.AIRTABLE_CLIENT_SECRET,
  redirectUri: process.env.AIRTABLE_REDIRECT_URI,
  
  // OAuth URLs
  authorizationUrl: 'https://airtable.com/oauth2/v1/authorize',
  tokenUrl: 'https://airtable.com/oauth2/v1/token',
  
  // API Base URL
  apiBaseUrl: 'https://api.airtable.com/v0',
  
  // OAuth Scopes
  scopes: [
    'data.records:read',
    'data.records:write',
    'schema.bases:read'
  ].join(' ')
};
