import axios from 'axios';
import crypto from 'crypto';
import { airtableConfig } from '../config/airtable.config.js';
import Token from '../models/Token.model.js';

// Generate random state for OAuth security
const generateState = () => {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

// Generate PKCE code verifier and challenge
const generateCodeVerifier = () => {
  return crypto.randomBytes(32).toString('base64url');
};

const generateCodeChallenge = (verifier) => {
  return crypto.createHash('sha256').update(verifier).digest('base64url');
};

export const initiateOAuth = (req, res) => {
  try {
    const state = generateState();
    const codeVerifier = generateCodeVerifier();
    const codeChallenge = generateCodeChallenge(codeVerifier);
    
    // Store state and code verifier in session
    req.session.oauthState = state;
    req.session.codeVerifier = codeVerifier;
    
    console.log("🚀 ~ airtableConfig:", airtableConfig);
    console.log("🔐 PKCE:", { codeChallenge, codeVerifier, state });
    
    // Save session before redirecting
    req.session.save((err) => {
      if (err) {
        console.error('Session save error:', err);
        return res.status(500).json({ error: 'Failed to save session' });
      }
      
      const authUrl = `${airtableConfig.authorizationUrl}?` +
        `client_id=${airtableConfig.clientId}&` +
        `redirect_uri=${encodeURIComponent(airtableConfig.redirectUri)}&` +
        `response_type=code&` +
        `state=${state}&` +
        `code_challenge=${codeChallenge}&` +
        `code_challenge_method=S256&` +
        `scope=${encodeURIComponent(airtableConfig.scopes)}`;
      
      res.json({ authUrl });
    });
  } catch (error) {
    console.error('OAuth initiation error:', error);
    res.status(500).json({ 
      error: 'Failed to initiate OAuth', 
      message: error.message 
    });
  }
};

export const handleCallback = async (req, res) => {
  try {
    console.log('Callback received with query params:', req.query);
    console.log('Session state:', req.session.oauthState);
    console.log('Session code verifier:', req.session.codeVerifier);
    
    const { code, state } = req.query;
    
    if (!code) {
      console.error('No authorization code received');
      return res.status(400).json({ 
        error: 'No authorization code provided' 
      });
    }
    
    // Verify state to prevent CSRF attacks
    if (state !== req.session.oauthState) {
      console.error('State mismatch:', { received: state, expected: req.session.oauthState });
      return res.status(400).json({ 
        error: 'Invalid state parameter' 
      });
    }
    
    if (!req.session.codeVerifier) {
      console.error('No code verifier in session');
      return res.status(400).json({ 
        error: 'Session lost. Please try again.' 
      });
    }
    
    console.log('Using code verifier:', req.session.codeVerifier);
    
    // Exchange code for access token with PKCE
    // Airtable requires Basic Auth with client credentials
    const authHeader = Buffer.from(`${airtableConfig.clientId}:${airtableConfig.clientSecret}`).toString('base64');
    
    const tokenResponse = await axios.post(
      airtableConfig.tokenUrl,
      new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: airtableConfig.redirectUri,
        code_verifier: req.session.codeVerifier
      }).toString(),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Basic ${authHeader}`
        }
      }
    );
    
    const { 
      access_token, 
      refresh_token, 
      expires_in, 
      scope 
    } = tokenResponse.data;
    
    // Get user info
    const userResponse = await axios.get('https://api.airtable.com/v0/meta/whoami', {
      headers: {
        'Authorization': `Bearer ${access_token}`
      }
    });
    
    const userId = userResponse.data.id;
    
    // Calculate expiration date
    const expiresAt = new Date(Date.now() + expires_in * 1000);
    
    // Store or update token in database
    await Token.findOneAndUpdate(
      { userId },
      {
        userId,
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresAt,
        scopes: scope.split(' ')
      },
      { upsert: true, new: true }
    );
    
    // Store userId in session
    req.session.userId = userId;
    
    // Redirect to frontend
    res.redirect(`${process.env.FRONTEND_URL}/dashboard?auth=success`);
  } catch (error) {
    console.error('OAuth callback error:', error);
    res.redirect(`${process.env.FRONTEND_URL}?auth=failed&error=${encodeURIComponent(error.message)}`);
  }
};

export const logout = async (req, res) => {
  try {
    const userId = req.session.userId;
    
    if (userId) {
      // Optionally, you can delete the token from database
      // await Token.findOneAndDelete({ userId });
    }
    
    req.session.destroy();
    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ 
      error: 'Logout failed', 
      message: error.message 
    });
  }
};

export const getAuthStatus = async (req, res) => {
  try {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.json({ authenticated: false });
    }
    
    const token = await Token.findOne({ userId });
    
    if (!token || new Date() >= token.expiresAt) {
      return res.json({ authenticated: false });
    }
    
    res.json({ 
      authenticated: true,
      userId,
      expiresAt: token.expiresAt
    });
  } catch (error) {
    console.error('Auth status error:', error);
    res.status(500).json({ 
      error: 'Failed to check auth status', 
      message: error.message 
    });
  }
};
