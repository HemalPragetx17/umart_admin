import axios from 'axios';
import cookieManager from '../services/cookieManager.js';
import revisionHistoryParser from '../services/revisionHistoryParser.js';
import RevisionHistory from '../models/RevisionHistory.model.js';
import Page from '../models/Page.model.js';

/**
 * Set cookies for scraping (with MFA support)
 */
export const setCookies = async (req, res) => {
  try {
    const { email, password, mfaCode, userId, cookies: manualCookies } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'userId is required' });
    }

    let cookies, csrfToken;

    // Option 1: Manual cookies from browser
    if (manualCookies) {
      cookies = cookieManager.parseBrowserCookies(manualCookies);
      csrfToken = null;
    } 
    // Option 2: Login with credentials
    else if (email && password) {
      const loginResult = await cookieManager.loginAndGetCookies(email, password, mfaCode);
      cookies = loginResult.cookies;
      csrfToken = loginResult.csrfToken;
    } 
    else {
      return res.status(400).json({ 
        error: 'Either provide cookies or email/password for login' 
      });
    }

    // Validate cookies
    const isValid = await cookieManager.validateCookies(userId, cookies);

    if (!isValid) {
      return res.status(401).json({ 
        error: 'Invalid cookies',
        message: 'The provided cookies are not valid or have expired'
      });
    }

    // Store cookies
    await cookieManager.storeCookies(userId, cookies, csrfToken);

    res.json({ 
      success: true,
      message: 'Cookies stored successfully',
      isValid: true
    });
  } catch (error) {
    console.error('Set cookies error:', error);
    res.status(500).json({ 
      error: 'Failed to set cookies',
      message: error.message 
    });
  }
};

/**
 * Validate existing cookies
 */
export const validateCookies = async (req, res) => {
  try {
    const { userId } = req.params;

    const cookieData = await cookieManager.getCookies(userId);

    if (!cookieData) {
      return res.json({ 
        isValid: false,
        message: 'No cookies found for this user'
      });
    }

    const isValid = await cookieManager.validateCookies(userId, cookieData.cookies);

    res.json({ 
      isValid,
      lastValidated: new Date()
    });
  } catch (error) {
    console.error('Validate cookies error:', error);
    res.status(500).json({ 
      error: 'Failed to validate cookies',
      message: error.message 
    });
  }
};

/**
 * Fetch revision history for a single record
 */
export const fetchRevisionHistory = async (req, res) => {
  try {
    const { baseId, tableId, recordId } = req.params;
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'userId query parameter is required' });
    }

    console.log(`📋 Fetching revision history for:`);
    console.log(`   Base ID: ${baseId}`);
    console.log(`   Table ID: ${tableId}`);
    console.log(`   Record ID: ${recordId}`);
    console.log(`   User ID: ${userId}`);

    // Get cookies
    const cookieData = await cookieManager.getCookies(userId);
    if (!cookieData || !cookieData.isValid) {
      return res.status(401).json({ 
        error: 'Invalid or missing cookies',
        message: 'Please set valid cookies first'
      });
    }

    console.log(`🍪 Cookies found and valid for user: ${userId}`);

    // Fetch revision history from Airtable
    const revisionHtml = await fetchAirtableRevisionHistory(
      baseId, 
      tableId, 
      recordId, 
      cookieData.cookies,
      cookieData.csrfToken
    );

    // Parse HTML
    const changes = revisionHistoryParser.parseRevisionHistory(revisionHtml);

    console.log(`✅ Found ${changes.length} changes for record ${recordId}`);

    // Store in database
    await RevisionHistory.findOneAndUpdate(
      { airtableRecordId: recordId },
      {
        airtableRecordId: recordId,
        baseId,
        tableId,
        changes,
        lastScraped: new Date()
      },
      { upsert: true, new: true }
    );

    res.json({
      recordId,
      changesFound: changes.length,
      changes
    });
  } catch (error) {
    console.error('❌ Fetch revision history error:', error);
    res.status(500).json({ 
      error: 'Failed to fetch revision history',
      message: error.message 
    });
  }
};

/**
 * Bulk fetch revision history for multiple records
 */
export const bulkFetchRevisionHistory = async (req, res) => {
  try {
    const { baseId, tableId, userId, limit = 200 } = req.body;

    if (!userId) {
      return res.status(400).json({ error: 'userId is required' });
    }

    if (!baseId || !tableId) {
      return res.status(400).json({ 
        error: 'baseId and tableId are required',
        message: 'Please provide both baseId and tableId'
      });
    }

    // Get cookies
    const cookieData = await cookieManager.getCookies(userId);
    if (!cookieData || !cookieData.isValid) {
      return res.status(401).json({ 
        error: 'Invalid or missing cookies',
        message: 'Please set valid cookies first'
      });
    }

    // Get all pages/records from MongoDB
    const pages = await Page.find({ baseId, tableId }).limit(parseInt(limit));

    if (pages.length === 0) {
      return res.status(404).json({
        error: 'No records found in database',
        message: 'Please sync the table data to MongoDB first by selecting the table and waiting for records to load. Records are automatically synced when you view them.',
        results: {
          total: 0,
          processed: 0,
          successful: 0,
          failed: 0,
          errors: []
        }
      });
    }

    console.log(`📊 Starting bulk fetch for ${pages.length} records...`);
    console.log(`Base ID: ${baseId}, Table ID: ${tableId}, User ID: ${userId}`);

    const results = {
      total: pages.length,
      processed: 0,
      successful: 0,
      failed: 0,
      errors: []
    };

    // Process in batches to avoid overwhelming the server
    const batchSize = 10;
    for (let i = 0; i < pages.length; i += batchSize) {
      const batch = pages.slice(i, i + batchSize);
      
      await Promise.all(batch.map(async (page) => {
        try {
          console.log(`Fetching revision history for record: ${page.airtableId}`);
          
          // Fetch revision history
          const revisionHtml = await fetchAirtableRevisionHistory(
            baseId,
            tableId,
            page.airtableId,
            cookieData.cookies,
            cookieData.csrfToken
          );

          // Parse changes
          const changes = revisionHistoryParser.parseRevisionHistory(revisionHtml);

          console.log(`Found ${changes.length} changes for record ${page.airtableId}`);

          // Store in database
          await RevisionHistory.findOneAndUpdate(
            { airtableRecordId: page.airtableId },
            {
              airtableRecordId: page.airtableId,
              baseId,
              tableId,
              changes,
              lastScraped: new Date()
            },
            { upsert: true, new: true }
          );

          results.successful++;
        } catch (error) {
          console.error(`❌ Error processing record ${page.airtableId}:`, error.message);
          results.failed++;
          results.errors.push({
            recordId: page.airtableId,
            error: error.message
          });
        } finally {
          results.processed++;
        }
      }));

      // Add small delay between batches
      if (i + batchSize < pages.length) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      console.log(`✅ Processed ${results.processed}/${pages.length} records...`);
    }

    console.log(`🎉 Bulk fetch completed! Successful: ${results.successful}, Failed: ${results.failed}`);

    res.json({
      message: 'Bulk fetch completed',
      results
    });
  } catch (error) {
    console.error('Bulk fetch error:', error);
    res.status(500).json({ 
      error: 'Bulk fetch failed',
      message: error.message 
    });
  }
};

/**
 * Get stored revision history
 */
export const getRevisionHistory = async (req, res) => {
  try {
    const { recordId } = req.params;

    const history = await RevisionHistory.findOne({ airtableRecordId: recordId });

    if (!history) {
      return res.status(404).json({ 
        error: 'Revision history not found',
        message: 'No revision history found for this record'
      });
    }

    res.json(history);
  } catch (error) {
    console.error('Get revision history error:', error);
    res.status(500).json({ 
      error: 'Failed to get revision history',
      message: error.message 
    });
  }
};

/**
 * Test endpoint to debug revision history URL
 */
export const testRevisionHistoryUrl = async (req, res) => {
  try {
    const { baseId, tableId, recordId } = req.params;
    const { userId } = req.query;

    if (!userId) {
      return res.status(400).json({ error: 'userId query parameter is required' });
    }

    const cookieData = await cookieManager.getCookies(userId);
    if (!cookieData) {
      return res.status(401).json({ error: 'No cookies found for user' });
    }

    const testResults = [];
    
    const urlFormats = [
      `https://airtable.com/${baseId}/${tableId}/${recordId}/readRowActivitiesAndComments`,
      `https://airtable.com/v0.3/${baseId}/${tableId}/${recordId}/readRowActivitiesAndComments`,
      `https://airtable.com/${baseId}/${recordId}/readRowActivitiesAndComments`,
      `https://airtable.com/${baseId}/${tableId}/${recordId}`,
      `https://airtable.com/${baseId}/${recordId}`,
    ];

    for (const url of urlFormats) {
      try {
        const response = await axios.head(url, {
          headers: {
            'Cookie': cookieData.cookies,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          },
          timeout: 5000,
          maxRedirects: 0,
          validateStatus: () => true
        });

        testResults.push({
          url,
          status: response.status,
          statusText: response.statusText,
          success: response.status === 200
        });
      } catch (error) {
        testResults.push({
          url,
          error: error.message,
          success: false
        });
      }
    }

    res.json({
      baseId,
      tableId,
      recordId,
      testResults,
      recommendation: testResults.find(r => r.success)?.url || 'None of the URLs worked'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

/**
 * Helper function to fetch revision history from Airtable
 */
async function fetchAirtableRevisionHistory(baseId, tableId, recordId, cookies, csrfToken) {
  try {
    // Airtable's actual API v0.3 endpoints that are used by their interface
    const possibleUrls = [
      // Format 1: Activity feed API endpoint (most likely)
      `https://airtable.com/v0.3/table/${tableId}/row/${recordId}/activityFeed?includeComments=true&includeActivities=true`,
      // Format 2: Row activities endpoint with base context
      `https://airtable.com/v0.3/base/${baseId}/table/${tableId}/row/${recordId}/activityFeed`,
      // Format 3: Direct activities endpoint
      `https://airtable.com/v0.3/row/${recordId}/activityFeed`,
      // Format 4: Record history endpoint
      `https://airtable.com/v0.3/table/${tableId}/row/${recordId}/history`,
      // Format 5: Original documented endpoint
      `https://airtable.com/${baseId}/${tableId}/${recordId}/readRowActivitiesAndComments`,
    ];

    let lastError = null;
    
    for (let i = 0; i < possibleUrls.length; i++) {
      const url = possibleUrls[i];
      
      try {
        console.log(`Trying URL format ${i + 1}: ${url}`);
        
        const response = await axios.get(url, {
          headers: {
            'Cookie': cookies,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Referer': `https://airtable.com/${baseId}/${tableId}`,
            'X-CSRF-Token': csrfToken || '',
            'X-Requested-With': 'XMLHttpRequest',
            'X-Airtable-Application-Id': baseId,
            'X-Airtable-Page-Load-Id': `pgl${Date.now()}`,
            'X-Time-Zone': 'America/Los_Angeles',
            'X-User-Locale': 'en',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Origin': 'https://airtable.com'
          },
          timeout: 30000,
          maxRedirects: 5,
          validateStatus: (status) => status === 200
        });

        if (response.status === 200 && response.data) {
          console.log(`✅ Success with URL format ${i + 1}`);
          console.log(`Response type: ${typeof response.data}`);
          
          // If it's JSON, we might need to extract HTML or parse differently
          if (typeof response.data === 'object') {
            console.log(`Response keys: ${Object.keys(response.data).join(', ')}`);
          }
          
          return response.data;
        }
      } catch (error) {
        console.log(`❌ URL format ${i + 1} failed: ${error.message}`);
        lastError = error;
        
        // If it's a 401/403, don't try other URLs - it's a cookie issue
        if (error.response?.status === 401 || error.response?.status === 403) {
          throw new Error('Cookies expired or invalid. Please refresh cookies.');
        }
        
        // Continue to next URL format
        continue;
      }
    }
    
    // If all URL formats failed, throw the last error
    throw new Error(`All URL formats failed. Last error: ${lastError?.message || 'Unknown error'}. Status: ${lastError?.response?.status || 'N/A'}. This endpoint may not be publicly accessible or may require different authentication.`);
    
  } catch (error) {
    if (error.response?.status === 401 || error.response?.status === 403) {
      throw new Error('Cookies expired or invalid. Please refresh cookies.');
    }
    if (error.response?.status === 404) {
      throw new Error('Revision history endpoint not found. Airtable may have changed their API or this feature requires additional permissions.');
    }
    throw error;
  }
}
