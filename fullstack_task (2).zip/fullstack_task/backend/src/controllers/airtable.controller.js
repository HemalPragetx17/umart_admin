import axios from 'axios';
import { airtableConfig } from '../config/airtable.config.js';
import Page from '../models/Page.model.js';

const makeAirtableRequest = async (accessToken, endpoint) => {
  const response = await axios.get(`${airtableConfig.apiBaseUrl}${endpoint}`, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });
  return response.data;
};

// Get all bases (projects)
export const getBases = async (req, res) => {
  try {
    const data = await makeAirtableRequest(req.accessToken, '/meta/bases');
    res.json(data);
  } catch (error) {
    console.error('Get bases error:', error);
    res.status(error.response?.status || 500).json({
      error: 'Failed to fetch bases',
      message: error.response?.data?.error?.message || error.message
    });
  }
};

// Get tables for a specific base
export const getTables = async (req, res) => {
  try {
    const { baseId } = req.params;
    const data = await makeAirtableRequest(req.accessToken, `/meta/bases/${baseId}/tables`);
    res.json(data);
  } catch (error) {
    console.error('Get tables error:', error);
    res.status(error.response?.status || 500).json({
      error: 'Failed to fetch tables',
      message: error.response?.data?.error?.message || error.message
    });
  }
};

// Get records (tickets/pages) from a table with pagination
export const getRecords = async (req, res) => {
  try {
    const { baseId, tableId } = req.params;
    const { offset, pageSize = 100 } = req.query;
    
    let endpoint = `/${baseId}/${tableId}?pageSize=${pageSize}`;
    if (offset) {
      endpoint += `&offset=${offset}`;
    }
    
    const data = await makeAirtableRequest(req.accessToken, endpoint);
    
    // Store records in MongoDB
    if (data.records && data.records.length > 0) {
      const pages = data.records.map(record => ({
        airtableId: record.id,
        baseId,
        tableId,
        fields: record.fields,
        createdTime: record.createdTime
      }));
      
      // Bulk upsert
      const bulkOps = pages.map(page => ({
        updateOne: {
          filter: { airtableId: page.airtableId },
          update: { $set: page },
          upsert: true
        }
      }));
      
      await Page.bulkWrite(bulkOps);
    }
    
    res.json({
      records: data.records,
      offset: data.offset,
      hasMore: !!data.offset
    });
  } catch (error) {
    console.error('Get records error:', error);
    res.status(error.response?.status || 500).json({
      error: 'Failed to fetch records',
      message: error.response?.data?.error?.message || error.message
    });
  }
};

// Get users
export const getUsers = async (req, res) => {
  try {
    // Note: Airtable API doesn't have a direct /Users endpoint
    // You might need to fetch users from a specific base/table
    // This is a placeholder implementation
    const data = await makeAirtableRequest(req.accessToken, '/meta/whoami');
    res.json(data);
  } catch (error) {
    console.error('Get users error:', error);
    res.status(error.response?.status || 500).json({
      error: 'Failed to fetch users',
      message: error.response?.data?.error?.message || error.message
    });
  }
};

// Sync all data from Airtable with pagination
export const syncAllData = async (req, res) => {
  try {
    const { baseId, tableId } = req.body;
    
    if (!baseId || !tableId) {
      return res.status(400).json({
        error: 'Missing parameters',
        message: 'baseId and tableId are required'
      });
    }
    
    let allRecords = [];
    let offset = null;
    let hasMore = true;
    
    // Fetch all pages with pagination
    while (hasMore) {
      let endpoint = `/${baseId}/${tableId}?pageSize=100`;
      if (offset) {
        endpoint += `&offset=${offset}`;
      }
      
      const data = await makeAirtableRequest(req.accessToken, endpoint);
      
      if (data.records && data.records.length > 0) {
        allRecords = allRecords.concat(data.records);
      }
      
      offset = data.offset;
      hasMore = !!offset;
    }
    
    // Store all records in MongoDB
    if (allRecords.length > 0) {
      const pages = allRecords.map(record => ({
        airtableId: record.id,
        baseId,
        tableId,
        fields: record.fields,
        createdTime: record.createdTime
      }));
      
      const bulkOps = pages.map(page => ({
        updateOne: {
          filter: { airtableId: page.airtableId },
          update: { $set: page },
          upsert: true
        }
      }));
      
      await Page.bulkWrite(bulkOps);
    }
    
    res.json({
      message: 'Sync completed successfully',
      totalRecords: allRecords.length,
      baseId,
      tableId
    });
  } catch (error) {
    console.error('Sync error:', error);
    res.status(error.response?.status || 500).json({
      error: 'Sync failed',
      message: error.response?.data?.error?.message || error.message
    });
  }
};
