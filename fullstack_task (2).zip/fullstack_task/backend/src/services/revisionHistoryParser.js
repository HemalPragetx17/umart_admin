import * as cheerio from 'cheerio';

class RevisionHistoryParser {
  /**
   * Parse HTML response from Airtable's readRowActivitiesAndComments endpoint
   * Focuses on extracting Assignee and Status changes
   */
  parseRevisionHistory(htmlContent) {
    const $ = cheerio.load(htmlContent);
    const changes = [];

    // Find all activity items
    $('.activity-feed-item, .revision-item, .activity-item').each((index, element) => {
      try {
        const $item = $(element);
        
        // Extract timestamp
        const timeElement = $item.find('.timestamp, .activity-timestamp, time');
        const timestamp = this.parseTimestamp(timeElement.text() || timeElement.attr('datetime'));

        // Extract user
        const userElement = $item.find('.user-name, .activity-user, .author');
        const user = userElement.text().trim() || 'Unknown User';

        // Extract change description
        const descriptionElement = $item.find('.activity-description, .change-description, .activity-text');
        const description = descriptionElement.text().trim();

        // Parse the change
        const parsedChange = this.parseChangeDescription(description);

        if (parsedChange && (parsedChange.changeType === 'assignee' || parsedChange.changeType === 'status')) {
          changes.push({
            timestamp: timestamp || new Date(),
            user,
            changeType: parsedChange.changeType,
            field: parsedChange.field,
            oldValue: parsedChange.oldValue,
            newValue: parsedChange.newValue,
            rawHtml: $.html(element)
          });
        }
      } catch (error) {
        console.error('Error parsing revision item:', error);
      }
    });

    // Also try alternative structure - JSON embedded in page
    const scriptTags = $('script');
    scriptTags.each((i, elem) => {
      const scriptContent = $(elem).html();
      if (scriptContent && scriptContent.includes('activities') || scriptContent.includes('revisions')) {
        try {
          const jsonMatch = scriptContent.match(/activities["\s:]+(\[.*?\])/s);
          if (jsonMatch) {
            const activities = JSON.parse(jsonMatch[1]);
            activities.forEach(activity => {
              const parsed = this.parseActivityObject(activity);
              if (parsed) {
                changes.push(parsed);
              }
            });
          }
        } catch (error) {
          // JSON parsing failed, continue
        }
      }
    });

    return changes;
  }

  /**
   * Parse change description text to identify change type and values
   */
  parseChangeDescription(description) {
    if (!description) return null;

    const lowerDesc = description.toLowerCase();

    // Check for assignee changes
    if (lowerDesc.includes('assign') || lowerDesc.includes('collaborator')) {
      const assigneeMatch = description.match(/(?:assigned to|changed assignee (?:from|to)|collaborator.*?to)\s+["']?([^"']+)["']?/i);
      const oldAssigneeMatch = description.match(/(?:from|was)\s+["']?([^"']+)["']?/i);
      
      return {
        changeType: 'assignee',
        field: 'Assignee',
        oldValue: oldAssigneeMatch ? oldAssigneeMatch[1].trim() : null,
        newValue: assigneeMatch ? assigneeMatch[1].trim() : null
      };
    }

    // Check for status changes
    if (lowerDesc.includes('status') || lowerDesc.includes('state')) {
      const statusMatch = description.match(/(?:status|state).*?(?:changed to|set to|is now)\s+["']?([^"']+)["']?/i);
      const oldStatusMatch = description.match(/(?:from|was)\s+["']?([^"']+)["']?/i);
      
      return {
        changeType: 'status',
        field: 'Status',
        oldValue: oldStatusMatch ? oldStatusMatch[1].trim() : null,
        newValue: statusMatch ? statusMatch[1].trim() : null
      };
    }

    // Alternative patterns for status/assignee
    if (lowerDesc.match(/to do|in progress|done|completed|pending/i)) {
      return {
        changeType: 'status',
        field: 'Status',
        oldValue: null,
        newValue: description
      };
    }

    return null;
  }

  /**
   * Parse activity object from JSON
   */
  parseActivityObject(activity) {
    if (!activity.changes) return null;

    for (const change of activity.changes) {
      const fieldName = change.field?.name?.toLowerCase() || '';
      
      if (fieldName.includes('assign') || change.type === 'assignee') {
        return {
          timestamp: new Date(activity.timestamp || activity.createdTime),
          user: activity.user?.name || 'Unknown User',
          changeType: 'assignee',
          field: change.field?.name || 'Assignee',
          oldValue: change.oldValue,
          newValue: change.newValue,
          rawHtml: JSON.stringify(activity)
        };
      }

      if (fieldName.includes('status') || change.type === 'status') {
        return {
          timestamp: new Date(activity.timestamp || activity.createdTime),
          user: activity.user?.name || 'Unknown User',
          changeType: 'status',
          field: change.field?.name || 'Status',
          oldValue: change.oldValue,
          newValue: change.newValue,
          rawHtml: JSON.stringify(activity)
        };
      }
    }

    return null;
  }

  /**
   * Parse various timestamp formats
   */
  parseTimestamp(timeString) {
    if (!timeString) return null;

    try {
      // Try ISO format first
      const isoDate = new Date(timeString);
      if (!isNaN(isoDate.getTime())) {
        return isoDate;
      }

      // Try relative time (e.g., "2 hours ago", "yesterday")
      const now = new Date();
      
      if (timeString.includes('just now') || timeString.includes('moments ago')) {
        return now;
      }

      const minutesMatch = timeString.match(/(\d+)\s*minute/i);
      if (minutesMatch) {
        return new Date(now.getTime() - parseInt(minutesMatch[1]) * 60 * 1000);
      }

      const hoursMatch = timeString.match(/(\d+)\s*hour/i);
      if (hoursMatch) {
        return new Date(now.getTime() - parseInt(hoursMatch[1]) * 60 * 60 * 1000);
      }

      const daysMatch = timeString.match(/(\d+)\s*day/i);
      if (daysMatch) {
        return new Date(now.getTime() - parseInt(daysMatch[1]) * 24 * 60 * 60 * 1000);
      }

      if (timeString.includes('yesterday')) {
        return new Date(now.getTime() - 24 * 60 * 60 * 1000);
      }

      return null;
    } catch (error) {
      console.error('Error parsing timestamp:', error);
      return null;
    }
  }
}

export default new RevisionHistoryParser();
