import axios from 'axios';
import * as cheerio from 'cheerio';
import AirtableCookie from '../models/AirtableCookie.model.js';

class CookieManager {
  /**
   * Store cookies for a user
   */
  async storeCookies(userId, cookies, csrfToken = null, expiresInDays = 30) {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + expiresInDays);

    await AirtableCookie.findOneAndUpdate(
      { userId },
      {
        userId,
        cookies,
        csrfToken,
        expiresAt,
        isValid: true,
        lastValidated: new Date()
      },
      { upsert: true, new: true }
    );

    console.log(`✅ Cookies stored for user: ${userId}`);
  }

  /**
   * Get cookies for a user
   */
  async getCookies(userId) {
    const cookieDoc = await AirtableCookie.findOne({ userId });
    
    if (!cookieDoc) {
      return null;
    }

    // Check if cookies are expired
    if (new Date() > cookieDoc.expiresAt) {
      console.log(`❌ Cookies expired for user: ${userId}`);
      return null;
    }

    return {
      cookies: cookieDoc.cookies,
      csrfToken: cookieDoc.csrfToken,
      isValid: cookieDoc.isValid
    };
  }

  /**
   * Validate cookies by making a test request
   */
  async validateCookies(userId, cookies) {
    try {
      const response = await axios.get('https://airtable.com/v0.3/user/usrrvepP6AclmjJ1z/listApplicationsAndPageBundlesForDisplay?stringifiedObjectParams=%7B%22shouldIncludePageBundleSharingApplications%22%3Afalse%2C%22shouldIncludePageBundleIndex%22%3Afalse%7D&requestId=reqH4nRLbXx4aekSp', {
        headers: {
          'Cookie': cookies,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 10000
      });

      const isValid = response.status === 200;

      // Update validation status
      await AirtableCookie.findOneAndUpdate(
        { userId },
        {
          isValid,
          lastValidated: new Date()
        }
      );

      return isValid;
    } catch (error) {
      console.error('Cookie validation failed:', error.message);
      
      // Mark as invalid
      await AirtableCookie.findOneAndUpdate(
        { userId },
        {
          isValid: false,
          lastValidated: new Date()
        }
      );

      return false;
    }
  }

  /**
   * Login to Airtable and retrieve cookies
   */
  async loginAndGetCookies(email, password, mfaCode = null) {
    try {
      // Step 1: Get login page to get CSRF token
      const loginPageResponse = await axios.get('https://airtable.com/login', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      const $ = cheerio.load(loginPageResponse.data);
      const csrfToken = $('meta[name="csrf-token"]').attr('content');
      const cookies = loginPageResponse.headers['set-cookie']?.join('; ') || '';

      // Step 2: Submit login credentials
      const loginData = {
        email,
        password,
        _csrf: csrfToken
      };

      const loginResponse = await axios.post('https://airtable.com/v0.3/auth/login', loginData, {
        headers: {
          'Cookie': cookies,
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken,
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        maxRedirects: 0,
        validateStatus: (status) => status < 400
      });

      let finalCookies = loginResponse.headers['set-cookie']?.join('; ') || cookies;

      // Step 3: If MFA is required and code is provided
      if (mfaCode && loginResponse.data?.requiresMfa) {
        const mfaResponse = await axios.post('https://airtable.com/v0.3/auth/mfa', {
          code: mfaCode,
          _csrf: csrfToken
        }, {
          headers: {
            'Cookie': finalCookies,
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        });

        finalCookies = mfaResponse.headers['set-cookie']?.join('; ') || finalCookies;
      }

      return {
        cookies: finalCookies,
        csrfToken
      };
    } catch (error) {
      console.error('Login failed:', error.message);
      throw new Error('Failed to login to Airtable: ' + error.message);
    }
  }

  /**
   * Extract cookies from browser format
   */
  parseBrowserCookies(browserCookieString) {
    // Handle both formats: "key=value; key2=value2" and array of cookie objects
    if (typeof browserCookieString === 'string') {
      return browserCookieString;
    }
    
    if (Array.isArray(browserCookieString)) {
      return browserCookieString.map(c => `${c.name}=${c.value}`).join('; ');
    }

    return '';
  }
}

export default new CookieManager();
