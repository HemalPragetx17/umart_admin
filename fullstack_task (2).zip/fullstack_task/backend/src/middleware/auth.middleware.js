import Token from '../models/Token.model.js';

export const requireAuth = async (req, res, next) => {
  try {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ 
        error: 'Unauthorized', 
        message: 'Please login first' 
      });
    }
    
    const token = await Token.findOne({ userId });
    
    if (!token) {
      return res.status(401).json({ 
        error: 'Unauthorized', 
        message: 'Token not found. Please login again' 
      });
    }
    
    // Check if token is expired
    if (new Date() >= token.expiresAt) {
      return res.status(401).json({ 
        error: 'Token expired', 
        message: 'Your session has expired. Please login again' 
      });
    }
    
    req.accessToken = token.accessToken;
    req.userId = userId;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({ 
      error: 'Server error', 
      message: 'Authentication failed' 
    });
  }
};
