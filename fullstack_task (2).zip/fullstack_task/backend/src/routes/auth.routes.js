import express from 'express';
import { initiateOAuth, handleCallback, logout, getAuthStatus } from '../controllers/auth.controller.js';

const router = express.Router();

router.get('/login', initiateOAuth);
router.get('/callback', handleCallback);
router.post('/logout', logout);
router.get('/status', getAuthStatus);

export default router;
