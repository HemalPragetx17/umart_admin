import express from 'express';
import { 
  setCookies,
  validateCookies,
  fetchRevisionHistory,
  bulkFetchRevisionHistory,
  getRevisionHistory,
  testRevisionHistoryUrl
} from '../controllers/scraping.controller.js';
import { requireAuth } from '../middleware/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(requireAuth);

// Cookie management
router.post('/cookies', setCookies);
router.get('/cookies/:userId/validate', validateCookies);

// Revision history
router.get('/revision-history/:baseId/:tableId/:recordId', fetchRevisionHistory);
router.post('/revision-history/bulk', bulkFetchRevisionHistory);
router.get('/revision-history/record/:recordId', getRevisionHistory);

// Debug endpoint
router.get('/test-url/:baseId/:tableId/:recordId', testRevisionHistoryUrl);

export default router;
