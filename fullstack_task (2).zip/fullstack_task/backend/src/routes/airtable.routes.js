import express from 'express';
import { 
  getBases, 
  getTables, 
  getRecords, 
  getUsers,
  syncAllData 
} from '../controllers/airtable.controller.js';
import { requireAuth } from '../middleware/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(requireAuth);

router.get('/bases', getBases);
router.get('/bases/:baseId/tables', getTables);
router.get('/bases/:baseId/tables/:tableId/records', getRecords);
router.get('/users', getUsers);
router.post('/sync', syncAllData);

export default router;
