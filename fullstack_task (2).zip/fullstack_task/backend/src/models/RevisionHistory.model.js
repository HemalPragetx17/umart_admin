import mongoose from 'mongoose';

const revisionHistorySchema = new mongoose.Schema({
  airtableRecordId: {
    type: String,
    required: true,
    index: true
  },
  baseId: {
    type: String,
    required: true
  },
  tableId: {
    type: String,
    required: true
  },
  changes: [{
    timestamp: {
      type: Date,
      required: true
    },
    user: {
      type: String,
      required: true
    },
    changeType: {
      type: String,
      enum: ['assignee', 'status', 'other'],
      required: true
    },
    field: {
      type: String,
      required: true
    },
    oldValue: {
      type: String
    },
    newValue: {
      type: String
    },
    rawHtml: {
      type: String
    }
  }],
  lastScraped: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Compound index for efficient queries
revisionHistorySchema.index({ baseId: 1, tableId: 1 });
revisionHistorySchema.index({ airtableRecordId: 1, 'changes.timestamp': -1 });

export default mongoose.model('RevisionHistory', revisionHistorySchema);
