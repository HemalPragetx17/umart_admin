import mongoose from 'mongoose';

const pageSchema = new mongoose.Schema({
  airtableId: {
    type: String,
    required: true,
    unique: true
  },
  baseId: {
    type: String,
    required: true
  },
  tableId: {
    type: String,
    required: true
  },
  fields: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  createdTime: {
    type: Date
  }
}, {
  timestamps: true
});

// Index for faster queries
pageSchema.index({ baseId: 1, tableId: 1 });

export default mongoose.model('Page', pageSchema);
