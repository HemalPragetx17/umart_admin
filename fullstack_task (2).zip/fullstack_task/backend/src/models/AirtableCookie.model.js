import mongoose from 'mongoose';

const airtableCookieSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true
  },
  cookies: {
    type: String,
    required: true
  },
  csrfToken: {
    type: String
  },
  expiresAt: {
    type: Date,
    required: true
  },
  isValid: {
    type: Boolean,
    default: true
  },
  lastValidated: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

export default mongoose.model('AirtableCookie', airtableCookieSchema);
