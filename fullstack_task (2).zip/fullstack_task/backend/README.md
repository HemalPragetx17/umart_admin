# Airtable Integration Backend

Node.js backend service for Airtable OAuth integration with MongoDB storage.

## Prerequisites

- Node.js v22 or higher
- MongoDB installed and running locally
- Airtable account with OAuth credentials

## Setup

1. Install dependencies:
```bash
npm install
```

2. Copy `.env.example` to `.env` and configure:
```bash
cp .env.example .env
```

3. Update `.env` with your credentials:
- Get Airtable OAuth credentials from: https://airtable.com/create/oauth
- Set `AIRTABLE_CLIENT_ID` and `AIRTABLE_CLIENT_SECRET`
- Configure `MONGODB_URI` if using remote MongoDB

4. Start the server:
```bash
# Development mode
npm run dev

# Production mode
npm start
```

## API Endpoints

### Authentication
- `GET /api/auth/login` - Initiate OAuth flow
- `GET /api/auth/callback` - OAuth callback handler
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/status` - Check authentication status

### Airtable Data (requires authentication)
- `GET /api/airtable/bases` - Get all bases (projects)
- `GET /api/airtable/bases/:baseId/tables` - Get tables for a base
- `GET /api/airtable/bases/:baseId/tables/:tableId/records` - Get records with pagination
- `GET /api/airtable/users` - Get user information
- `POST /api/airtable/sync` - Sync all data from a table to MongoDB

## Features

- ✅ OAuth 2.0 authentication with Airtable
- ✅ Automatic token management and storage
- ✅ Pagination support for large datasets
- ✅ MongoDB integration for data persistence
- ✅ Session-based authentication
- ✅ CORS enabled for frontend integration
- ✅ Error handling and logging
