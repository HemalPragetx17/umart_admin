# Airtable Integration Frontend

Angular 19 frontend application for Airtable integration with AG Grid and Angular Material.

## Prerequisites

- Node.js v22 or higher
- npm v10 or higher

## Setup

1. Install dependencies:
```bash
npm install
```

2. Update environment configuration:
   - Edit `src/environments/environment.ts` for development
   - Edit `src/environments/environment.prod.ts` for production

3. Start the development server:
```bash
npm start
```

The application will be available at `http://localhost:4200`

## Features

- ✅ Angular 19 with standalone components
- ✅ Angular Material UI components
- ✅ Material Icons
- ✅ AG Grid for data visualization (v33.0)
- ✅ OAuth authentication flow
- ✅ Route guards for protected routes
- ✅ HTTP interceptors for authentication
- ✅ Responsive design
- ✅ TypeScript strict mode

## Project Structure

```
src/
├── app/
│   ├── core/
│   │   ├── guards/          # Route guards
│   │   ├── interceptors/    # HTTP interceptors
│   │   ├── models/          # TypeScript interfaces
│   │   └── services/        # Services (auth, airtable)
│   ├── features/
│   │   ├── login/           # Login component
│   │   └── dashboard/       # Dashboard component
│   ├── app.component.ts
│   ├── app.config.ts
│   └── app.routes.ts
├── environments/            # Environment configurations
└── styles.scss             # Global styles
```

## Available Scripts

- `npm start` - Start development server
- `npm run build` - Build for production
- `npm run watch` - Build with watch mode
- `npm test` - Run unit tests

## Components

### Login Component
- Handles Airtable OAuth authentication
- Redirects to Airtable authorization page
- Beautiful gradient background with Material Design

### Dashboard Component
- Select bases (projects) and tables
- View records with AG Grid
- Pagination support
- Sync data to MongoDB
- Logout functionality

## AG Grid Integration

The dashboard uses AG Grid Community (v33.0) for displaying Airtable records with:
- Sorting
- Filtering
- Pagination
- Resizable columns
- Dynamic column generation based on record fields
