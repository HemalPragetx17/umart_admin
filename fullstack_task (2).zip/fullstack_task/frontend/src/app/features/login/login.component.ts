import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    MatProgressSpinnerModule
  ],
  template: `
    <mat-toolbar color="primary">
      <span>Airtable Integration</span>
    </mat-toolbar>

    <div class="login-container">
      <mat-card class="login-card">
        <mat-card-header>
          <mat-card-title>
            <mat-icon>cloud</mat-icon>
            Welcome to Airtable Integration
          </mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <p>Connect your Airtable account to manage your bases, tables, and records.</p>
          <div *ngIf="loading" class="loading">
            <mat-spinner diameter="40"></mat-spinner>
          </div>
        </mat-card-content>
        <mat-card-actions>
          <button 
            mat-raised-button 
            color="primary" 
            (click)="login()"
            [disabled]="loading">
            <mat-icon>login</mat-icon>
            Connect with Airtable
          </button>
        </mat-card-actions>
      </mat-card>
    </div>
  `,
  styles: [`
    .login-container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: calc(100vh - 64px);
      padding: 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .login-card {
      max-width: 500px;
      width: 100%;
      text-align: center;
    }

    mat-card-header {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }

    mat-card-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 24px;
    }

    mat-card-content {
      padding: 20px 0;
    }

    mat-card-actions {
      display: flex;
      justify-content: center;
      padding: 20px;
    }

    button {
      padding: 0 30px;
      height: 48px;
      font-size: 16px;
    }

    .loading {
      display: flex;
      justify-content: center;
      padding: 20px;
    }

    mat-icon {
      vertical-align: middle;
    }
  `]
})
export class LoginComponent implements OnInit {
  private authService = inject(AuthService);
  private router = inject(Router);
  loading = false;

  ngOnInit() {
    // Check if already authenticated
    this.authService.checkAuthStatus().subscribe(status => {
      if (status.authenticated) {
        this.router.navigate(['/dashboard']);
      }
    });
  }

  login() {
    this.loading = true;
    this.authService.login().subscribe({
      next: (response) => {
        // Redirect to Airtable OAuth page
        window.location.href = response.authUrl;
      },
      error: (error) => {
        console.error('Login error:', error);
        this.loading = false;
      }
    });
  }
}
