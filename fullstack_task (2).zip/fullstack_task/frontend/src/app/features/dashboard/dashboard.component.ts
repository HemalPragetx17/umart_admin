import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, ModuleRegistry } from 'ag-grid-community';
import { AllCommunityModule } from 'ag-grid-community';
import { AuthService } from '../../core/services/auth.service';
import { AirtableService } from '../../core/services/airtable.service';
import { ScrapingService } from '../../core/services/scraping.service';
import { AirtableBase, AirtableTable, AirtableRecord } from '../../core/models/airtable.model';

// Register AG Grid modules
ModuleRegistry.registerModules([AllCommunityModule]);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatFormFieldModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    AgGridAngular
  ],
  template: `
    <mat-toolbar color="primary">
      <span>Airtable Integration Dashboard</span>
      <span class="spacer"></span>
      <button mat-button (click)="toggleCookiePanel()">
        <mat-icon>cookie</mat-icon>
        Cookie Setup
      </button>
      <button mat-icon-button (click)="logout()">
        <mat-icon>logout</mat-icon>
      </button>
    </mat-toolbar>

    <div class="container">
      <!-- Cookie Management Panel -->
      <mat-card *ngIf="showCookiePanel" class="cookie-panel">
        <mat-card-header>
          <mat-card-title>
            <mat-icon class="title-icon">cookie</mat-icon>
            Cookie Management for Revision History Scraping
          </mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <div class="info-box">
            <mat-icon class="info-icon">info</mat-icon>
            <div>
              <strong>Why do I need cookies?</strong>
              <p>To fetch revision history from Airtable, we need authenticated access. You have two options:</p>
              <ul>
                <li><strong>Option 1:</strong> Paste cookies directly from your browser (Quick & Easy)</li>
                <li><strong>Option 2:</strong> Login with your Airtable credentials (Automatic cookie retrieval)</li>
              </ul>
            </div>
          </div>

          <!-- User ID Field -->
          <div class="field-section">
            <mat-form-field appearance="outline" style="width: 100%;">
              <mat-label>User ID (Required)</mat-label>
              <input matInput [(ngModel)]="cookieUserId" placeholder="e.g., user123 or yourname@company.com" required>
              <mat-hint>Enter a unique identifier for your session. This can be your email or any unique ID.</mat-hint>
            </mat-form-field>
          </div>

          <!-- Option 1: Manual Cookies -->
          <div class="option-section">
            <div class="option-header">
              <mat-icon>code</mat-icon>
              <strong>Option 1: Paste Browser Cookies</strong>
            </div>
            
            <div class="instructions-box">
              <p><strong>How to get cookies from your browser:</strong></p>
              <ol>
                <li>Open <a href="https://airtable.com" target="_blank">airtable.com</a> and login to your account</li>
                <li>Press <kbd>F12</kbd> to open Developer Tools</li>
                <li>Go to <strong>Application</strong> tab → <strong>Cookies</strong> → <strong>https://airtable.com</strong></li>
                <li>Copy the entire cookie string (format: <code>name=value; name2=value2</code>)</li>
                <li>Paste it in the field below</li>
              </ol>
              <p class="example-text">
                <mat-icon class="small-icon">lightbulb</mat-icon>
                <strong>Example format:</strong> 
                <code class="example-code">brw_session=abc123xyz; session_id=def456uvw; user_token=ghi789rst</code>
              </p>
            </div>

            <mat-form-field appearance="outline" style="width: 100%;">
              <mat-label>Cookie String</mat-label>
              <textarea 
                matInput 
                [(ngModel)]="cookieString" 
                rows="4" 
                placeholder="brw_session=xxx; session_id=yyy; user_token=zzz"></textarea>
              <mat-hint>Paste the complete cookie string from your browser's DevTools</mat-hint>
            </mat-form-field>
          </div>

          <div class="divider">
            <span>OR</span>
          </div>

          <!-- Option 2: Login Credentials -->
          <div class="option-section">
            <div class="option-header">
              <mat-icon>login</mat-icon>
              <strong>Option 2: Login with Airtable Credentials</strong>
            </div>
            
            <div class="instructions-box">
              <p><strong>Automatic cookie retrieval:</strong></p>
              <ul>
                <li>Enter your Airtable email and password below</li>
                <li>If you have MFA (Multi-Factor Authentication) enabled, provide the 6-digit code</li>
                <li>The system will automatically fetch and store your cookies</li>
              </ul>
              <p class="warning-text">
                <mat-icon class="small-icon">lock</mat-icon>
                Your credentials are used only to fetch cookies and are NOT stored permanently.
              </p>
            </div>

            <mat-form-field appearance="outline" style="width: 100%;">
              <mat-label>Airtable Email</mat-label>
              <input 
                matInput 
                [(ngModel)]="cookieEmail" 
                type="email"
                placeholder="yourname@example.com">
              <mat-hint>Your Airtable account email address</mat-hint>
            </mat-form-field>

            <mat-form-field appearance="outline" style="width: 100%;">
              <mat-label>Airtable Password</mat-label>
              <input 
                matInput 
                [(ngModel)]="cookiePassword" 
                type="password"
                placeholder="Enter your password">
              <mat-hint>Your Airtable account password</mat-hint>
            </mat-form-field>

            <mat-form-field appearance="outline" style="width: 100%;">
              <mat-label>MFA Code (Optional)</mat-label>
              <input 
                matInput 
                [(ngModel)]="mfaCode" 
                placeholder="123456"
                maxlength="6">
              <mat-hint>If you have Two-Factor Authentication enabled, enter the 6-digit code from your authenticator app</mat-hint>
            </mat-form-field>
          </div>

          <!-- Action Buttons -->
          <div class="button-row">
            <button 
              mat-raised-button 
              color="primary" 
              (click)="setCookies()" 
              [disabled]="settingCookies || !isFormValid()">
              <mat-icon>save</mat-icon>
              {{ settingCookies ? 'Saving Cookies...' : 'Save Cookies' }}
            </button>
            <button 
              mat-raised-button 
              color="accent"
              (click)="validateCookies()" 
              [disabled]="!cookieUserId || validating">
              <mat-icon>verified_user</mat-icon>
              {{ validating ? 'Validating...' : 'Validate Cookies' }}
            </button>
            <button 
              mat-stroked-button 
              (click)="clearCookieForm()">
              <mat-icon>clear</mat-icon>
              Clear Form
            </button>
          </div>

          <!-- Validation Status -->
          <div *ngIf="cookieValidationStatus" class="status-message" [class.success]="cookieValidationStatus.isValid" [class.error]="!cookieValidationStatus.isValid">
            <mat-icon>{{ cookieValidationStatus.isValid ? 'check_circle' : 'error' }}</mat-icon>
            <div class="status-text">
              <strong>{{ cookieValidationStatus.isValid ? 'Success!' : 'Failed' }}</strong>
              <p>{{ cookieValidationStatus.message }}</p>
              <p *ngIf="cookieValidationStatus.lastValidated" class="timestamp">
                Last validated: {{ cookieValidationStatus.lastValidated | date:'medium' }}
              </p>
            </div>
          </div>
        </mat-card-content>
      </mat-card>

      <mat-card class="selection-card">
        <mat-card-content>
          <div class="selection-row">
            <mat-form-field appearance="outline">
              <mat-label>Select Base (Project)</mat-label>
              <mat-select [(ngModel)]="selectedBase" (selectionChange)="onBaseChange()">
                <mat-option *ngFor="let base of bases" [value]="base">
                  {{ base.name }}
                </mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline" *ngIf="selectedBase">
              <mat-label>Select Table</mat-label>
              <mat-select [(ngModel)]="selectedTable" (selectionChange)="onTableChange()">
                <mat-option *ngFor="let table of tables" [value]="table">
                  {{ table.name }}
                </mat-option>
              </mat-select>
            </mat-form-field>

            <button 
              mat-raised-button 
              color="primary" 
              *ngIf="selectedBase && selectedTable"
              (click)="syncData()"
              [disabled]="syncing">
              <mat-icon>sync</mat-icon>
              Sync to MongoDB
            </button>

            <button 
              mat-raised-button 
              color="accent" 
              *ngIf="selectedBase && selectedTable"
              (click)="startBulkScraping()"
              [disabled]="scraping || !cookieUserId || records.length === 0">
              <mat-icon>history</mat-icon>
              {{ scraping ? 'Scraping...' : 'Fetch Revision History' }}
            </button>
          </div>

          <!-- Info message for revision history -->
          <div *ngIf="selectedBase && selectedTable && records.length === 0 && !loading" class="info-message">
            <mat-icon>info</mat-icon>
            <p>Please wait for records to load before fetching revision history. Records are automatically synced when you select a table.</p>
          </div>

          <div *ngIf="selectedBase && selectedTable && records.length > 0 && !cookieUserId" class="warning-message">
            <mat-icon>warning</mat-icon>
            <p>Please set up cookies first (click "Cookie Setup" button above) to fetch revision history.</p>
          </div>

          <div *ngIf="scraping" class="scraping-active">
            <mat-spinner diameter="40"></mat-spinner>
            <p>Scraping revision history in progress... Please wait.</p>
          </div>

          <div *ngIf="scrapingProgress && !scraping" class="scraping-progress">
            <div class="progress-header">
              <mat-icon [class.success]="scrapingProgress.failed === 0">{{ scrapingProgress.failed === 0 ? 'check_circle' : 'info' }}</mat-icon>
              <strong>Scraping Results</strong>
            </div>
            <div class="progress-stats">
              <div class="stat">
                <span class="label">Total Records:</span>
                <span class="value">{{ scrapingProgress.total }}</span>
              </div>
              <div class="stat success">
                <span class="label">Successful:</span>
                <span class="value">{{ scrapingProgress.successful }}</span>
              </div>
              <div class="stat" [class.error]="scrapingProgress.failed > 0">
                <span class="label">Failed:</span>
                <span class="value">{{ scrapingProgress.failed }}</span>
              </div>
            </div>
            <div *ngIf="scrapingProgress.errors && scrapingProgress.errors.length > 0" class="error-details">
              <p><strong>Errors:</strong></p>
              <ul>
                <li *ngFor="let err of scrapingProgress.errors.slice(0, 5)">
                  Record {{ err.recordId }}: {{ err.error }}
                </li>
              </ul>
              <p *ngIf="scrapingProgress.errors.length > 5" class="more-errors">
                ... and {{ scrapingProgress.errors.length - 5 }} more errors
              </p>
            </div>
          </div>
        </mat-card-content>
      </mat-card>

      <mat-card *ngIf="loading" class="loading-card">
        <mat-spinner></mat-spinner>
        <p>Loading data...</p>
      </mat-card>

      <mat-card *ngIf="!loading && records.length > 0" class="grid-card">
        <mat-card-header>
          <mat-card-title>
            Records ({{ records.length }})
            <button 
              mat-button 
              color="primary" 
              *ngIf="hasMore"
              (click)="loadMore()"
              [disabled]="loadingMore">
              <mat-icon>refresh</mat-icon>
              Load More
            </button>
          </mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <div class="grid-wrapper">
            <ag-grid-angular
              style="width: 100%; height: 600px;"
              class="ag-theme-material"
              [rowData]="gridData"
              [columnDefs]="columnDefs"
              [defaultColDef]="defaultColDef"
              [pagination]="true"
              [paginationPageSize]="20">
            </ag-grid-angular>
          </div>
        </mat-card-content>
      </mat-card>

      <mat-card *ngIf="!loading && records.length === 0 && selectedTable">
        <mat-card-content>
          <p style="text-align: center; padding: 40px; color: #666;">
            No records found in this table.
          </p>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .container {
      padding: 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .cookie-panel {
      margin-bottom: 24px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .cookie-panel mat-card-title {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 20px;
      color: #1976d2;
    }

    .title-icon {
      font-size: 28px;
      width: 28px;
      height: 28px;
    }

    .info-box {
      display: flex;
      gap: 16px;
      padding: 16px;
      background-color: #e3f2fd;
      border-left: 4px solid #2196f3;
      border-radius: 4px;
      margin-bottom: 24px;
    }

    .info-icon {
      color: #2196f3;
      font-size: 24px;
      width: 24px;
      height: 24px;
      flex-shrink: 0;
    }

    .info-box p {
      margin: 8px 0;
      color: #1565c0;
    }

    .info-box ul {
      margin: 8px 0;
      padding-left: 20px;
      color: #1565c0;
    }

    .info-box strong {
      color: #0d47a1;
    }

    .field-section {
      margin-bottom: 24px;
    }

    .option-section {
      margin-bottom: 24px;
      padding: 20px;
      background-color: #fafafa;
      border-radius: 8px;
      border: 1px solid #e0e0e0;
    }

    .option-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;
      color: #424242;
      font-size: 16px;
    }

    .option-header mat-icon {
      color: #1976d2;
    }

    .instructions-box {
      background-color: #fff;
      padding: 16px;
      border-radius: 4px;
      margin-bottom: 16px;
      border-left: 3px solid #ff9800;
    }

    .instructions-box p {
      margin: 8px 0;
      color: #424242;
    }

    .instructions-box ol,
    .instructions-box ul {
      margin: 8px 0;
      padding-left: 24px;
      color: #616161;
    }

    .instructions-box li {
      margin: 6px 0;
    }

    .instructions-box strong {
      color: #212121;
    }

    .instructions-box a {
      color: #1976d2;
      text-decoration: none;
    }

    .instructions-box a:hover {
      text-decoration: underline;
    }

    .instructions-box kbd {
      background-color: #f5f5f5;
      border: 1px solid #ccc;
      border-radius: 3px;
      padding: 2px 6px;
      font-family: monospace;
      font-size: 12px;
    }

    .example-text {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      background-color: #f5f5f5;
      padding: 12px;
      border-radius: 4px;
      margin-top: 12px;
    }

    .small-icon {
      font-size: 18px;
      width: 18px;
      height: 18px;
      color: #ff9800;
      flex-shrink: 0;
    }

    .example-code {
      background-color: #263238;
      color: #aed581;
      padding: 2px 6px;
      border-radius: 3px;
      font-family: 'Courier New', monospace;
      font-size: 13px;
      word-break: break-all;
    }

    .warning-text {
      display: flex;
      align-items: center;
      gap: 8px;
      background-color: #fff3e0;
      padding: 12px;
      border-radius: 4px;
      color: #e65100;
      margin-top: 12px;
    }

    .warning-text .small-icon {
      color: #ff9800;
    }

    .divider {
      text-align: center;
      margin: 32px 0;
      position: relative;
      color: #9e9e9e;
      font-weight: 500;
    }

    .divider::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 1px;
      background-color: #e0e0e0;
      z-index: 0;
    }

    .divider span {
      background-color: #fff;
      padding: 0 20px;
      position: relative;
      z-index: 1;
    }

    .button-row {
      display: flex;
      gap: 12px;
      margin-top: 24px;
      flex-wrap: wrap;
    }

    .status-message {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 16px;
      margin-top: 20px;
      border-radius: 8px;
      border-left: 4px solid;
    }

    .status-message.success {
      background-color: #e8f5e9;
      border-color: #4caf50;
      color: #2e7d32;
    }

    .status-message.success mat-icon {
      color: #4caf50;
    }

    .status-message.error {
      background-color: #ffebee;
      border-color: #f44336;
      color: #c62828;
    }

    .status-message.error mat-icon {
      color: #f44336;
    }

    .status-message mat-icon {
      font-size: 24px;
      width: 24px;
      height: 24px;
      flex-shrink: 0;
    }

    .status-text {
      flex: 1;
    }

    .status-text strong {
      font-size: 16px;
      display: block;
      margin-bottom: 4px;
    }

    .status-text p {
      margin: 4px 0;
    }

    .timestamp {
      font-size: 12px;
      opacity: 0.8;
      margin-top: 8px !important;
    }

    .selection-card {
      margin-bottom: 20px;
    }

    .selection-row {
      display: flex;
      gap: 20px;
      align-items: center;
      flex-wrap: wrap;
    }

    .info-message {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 16px;
      background-color: #e3f2fd;
      border-left: 4px solid #2196f3;
      border-radius: 4px;
      margin-top: 16px;
      color: #1565c0;
    }

    .info-message mat-icon {
      color: #2196f3;
      flex-shrink: 0;
    }

    .info-message p {
      margin: 0;
    }

    .warning-message {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 16px;
      background-color: #fff3e0;
      border-left: 4px solid #ff9800;
      border-radius: 4px;
      margin-top: 16px;
      color: #e65100;
    }

    .warning-message mat-icon {
      color: #ff9800;
      flex-shrink: 0;
    }

    .warning-message p {
      margin: 0;
    }

    .scraping-active {
      display: flex;
      align-items: center;
      gap: 16px;
      padding: 16px;
      background-color: #e8f5e9;
      border-radius: 4px;
      margin-top: 16px;
    }

    .scraping-active p {
      margin: 0;
      color: #2e7d32;
      font-weight: 500;
    }

    .scraping-progress {
      margin-top: 16px;
      padding: 20px;
      background-color: #f5f5f5;
      border-radius: 8px;
      border: 1px solid #e0e0e0;
    }

    .progress-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 2px solid #e0e0e0;
    }

    .progress-header mat-icon {
      font-size: 28px;
      width: 28px;
      height: 28px;
      color: #2196f3;
    }

    .progress-header mat-icon.success {
      color: #4caf50;
    }

    .progress-header strong {
      font-size: 18px;
      color: #424242;
    }

    .progress-stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 16px;
      margin-bottom: 16px;
    }

    .stat {
      display: flex;
      flex-direction: column;
      padding: 12px;
      background-color: #fff;
      border-radius: 4px;
      border-left: 3px solid #2196f3;
    }

    .stat.success {
      border-left-color: #4caf50;
    }

    .stat.error {
      border-left-color: #f44336;
    }

    .stat .label {
      font-size: 12px;
      color: #757575;
      margin-bottom: 4px;
    }

    .stat .value {
      font-size: 24px;
      font-weight: 600;
      color: #212121;
    }

    .error-details {
      background-color: #ffebee;
      padding: 12px;
      border-radius: 4px;
      border-left: 3px solid #f44336;
    }

    .error-details p {
      margin: 8px 0;
      color: #c62828;
      font-weight: 500;
    }

    .error-details ul {
      margin: 8px 0;
      padding-left: 20px;
      color: #d32f2f;
    }

    .error-details li {
      margin: 4px 0;
      font-size: 13px;
    }

    .more-errors {
      font-style: italic;
      opacity: 0.8;
    }

    .scraping-progress p {
      margin: 4px 0;
      color: #1565c0;
    }

    mat-form-field {
      min-width: 250px;
    }

    .loading-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 40px;
    }

    .loading-card p {
      margin-top: 20px;
      font-size: 16px;
    }

    .grid-card {
      margin-top: 20px;
    }

    .grid-wrapper {
      width: 100%;
      height: 600px;
    }

    mat-card-header {
      margin-bottom: 20px;
    }

    mat-card-title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
    }

    :host ::ng-deep .ag-theme-material {
      --ag-border-color: #e0e0e0;
    }
  `]
})
export class DashboardComponent implements OnInit {
  private authService = inject(AuthService);
  private airtableService = inject(AirtableService);
  private scrapingService = inject(ScrapingService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private snackBar = inject(MatSnackBar);

  bases: AirtableBase[] = [];
  tables: AirtableTable[] = [];
  records: AirtableRecord[] = [];
  selectedBase: AirtableBase | null = null;
  selectedTable: AirtableTable | null = null;
  loading = false;
  loadingMore = false;
  syncing = false;
  scraping = false;
  offset: string | undefined;
  hasMore = false;

  // Cookie management
  showCookiePanel = false;
  cookieUserId = '';
  cookieString = '';
  cookieEmail = '';
  cookiePassword = '';
  mfaCode = '';
  settingCookies = false;
  validating = false;
  cookieValidationStatus: any = null;
  scrapingProgress: any = null;

  // AG Grid configuration
  columnDefs: ColDef[] = [];
  gridData: any[] = [];
  defaultColDef: ColDef = {
    sortable: true,
    filter: true,
    resizable: true,
    minWidth: 100
  };

  ngOnInit() {
    this.loadBases();
    
    // Check for auth success
    this.route.queryParams.subscribe(params => {
      if (params['auth'] === 'success') {
        this.snackBar.open('Successfully authenticated with Airtable!', 'Close', {
          duration: 3000
        });
      } else if (params['auth'] === 'failed') {
        this.snackBar.open('Authentication failed. Please try again.', 'Close', {
          duration: 5000
        });
      }
    });
  }

  loadBases() {
    this.loading = true;
    this.airtableService.getBases().subscribe({
      next: (response) => {
        this.bases = response.bases;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading bases:', error);
        this.snackBar.open('Error loading bases', 'Close', { duration: 3000 });
        this.loading = false;
      }
    });
  }

  onBaseChange() {
    if (this.selectedBase) {
      this.selectedTable = null;
      this.records = [];
      this.gridData = [];
      this.columnDefs = [];
      this.loadTables(this.selectedBase.id);
    }
  }

  loadTables(baseId: string) {
    this.loading = true;
    this.airtableService.getTables(baseId).subscribe({
      next: (response) => {
        this.tables = response.tables;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading tables:', error);
        this.snackBar.open('Error loading tables', 'Close', { duration: 3000 });
        this.loading = false;
      }
    });
  }

  onTableChange() {
    console.log('=== TABLE CHANGED ===');
    console.log('Selected Base:', this.selectedBase);
    console.log('Selected Table:', this.selectedTable);
    
    if (this.selectedBase && this.selectedTable) {
      this.records = [];
      this.gridData = [];
      this.columnDefs = [];
      this.offset = undefined;
      this.loadRecords(this.selectedBase.id, this.selectedTable.id);
    }
  }

  loadRecords(baseId: string, tableId: string, offset?: string) {
    console.log('=== LOAD RECORDS CALLED ===');
    console.log('Base ID:', baseId);
    console.log('Table ID:', tableId);
    console.log('Offset:', offset);
    
    this.loading = !offset;
    this.loadingMore = !!offset;
    
    this.airtableService.getRecords(baseId, tableId, offset).subscribe({
      next: (response) => {
        console.log('=== RECORDS RESPONSE ===');
        console.log('Raw response:', response);
        console.log('Number of records:', response.records?.length);
        console.log('First record sample:', response.records?.[0]);
        
        this.records = offset ? [...this.records, ...response.records] : response.records;
        this.offset = response.offset;
        this.hasMore = response.hasMore;
        
        console.log('Total records after merge:', this.records.length);
        
        this.updateGrid();
        this.loading = false;
        this.loadingMore = false;
      },
      error: (error) => {
        console.error('=== ERROR LOADING RECORDS ===');
        console.error('Error:', error);
        this.snackBar.open('Error loading records', 'Close', { duration: 3000 });
        this.loading = false;
        this.loadingMore = false;
      }
    });
  }

  loadMore() {
    if (this.selectedBase && this.selectedTable && this.offset) {
      this.loadRecords(this.selectedBase.id, this.selectedTable.id, this.offset);
    }
  }

  updateGrid() {
    console.log('=== UPDATE GRID CALLED ===');
    console.log('Records count:', this.records.length);
    
    if (this.records.length === 0) {
      console.log('No records to display - clearing grid');
      this.gridData = [];
      this.columnDefs = [];
      return;
    }

    console.log('Full records data:', JSON.stringify(this.records, null, 2));

    // Extract all unique field names
    const fieldNames = new Set<string>();
    this.records.forEach(record => {
      if (record.fields) {
        Object.keys(record.fields).forEach(key => fieldNames.add(key));
      }
    });

    console.log('Unique field names:', Array.from(fieldNames));

    // Create column definitions with custom renderers
    this.columnDefs = [
      { 
        field: 'id', 
        headerName: 'ID', 
        width: 180,
        pinned: 'left' as const
      },
      // Special handling for common fields
      ...(fieldNames.has('User Name') ? [{
        field: 'User Name',
        headerName: 'User Name',
        width: 200,
        pinned: 'left' as const
      }] : []),
      ...(fieldNames.has('Profile Photo') ? [{
        field: 'Profile Photo',
        headerName: 'Profile Photo',
        width: 120,
        cellRenderer: (params: any) => {
          if (params.value && Array.isArray(params.value) && params.value[0]?.url) {
            return `<img src="${params.value[0].url}" style="width: 40px; height: 40px; border-radius: 4px; object-fit: cover;" />`;
          }
          return '';
        }
      }] : []),
      ...(fieldNames.has('Role') ? [{
        field: 'Role',
        headerName: 'Role',
        width: 150,
        cellRenderer: (params: any) => {
          if (!params.value) return '';
          const role = params.value;
          let color = '#e3f2fd'; // default blue
          let textColor = '#1976d2';
          
          if (role === 'Owner') {
            color = '#e3f2fd';
            textColor = '#1976d2';
          } else if (role === 'Admin') {
            color = '#c8e6c9';
            textColor = '#388e3c';
          } else if (role === 'Collaborator') {
            color = '#b3e5fc';
            textColor = '#0277bd';
          } else if (role === 'Read Only') {
            color = '#fff9c4';
            textColor = '#f57f17';
          } else {
            color = '#ffe0b2';
            textColor = '#e65100';
          }
          
          return `<span style="background-color: ${color}; color: ${textColor}; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">${role}</span>`;
        }
      }] : []),
      ...(fieldNames.has('Status') ? [{
        field: 'Status',
        headerName: 'Status',
        width: 130,
        cellRenderer: (params: any) => {
          if (!params.value) return '';
          const status = params.value;
          let color = '#e3f2fd';
          let textColor = '#1976d2';
          
          if (status === 'Active') {
            color = '#e3f2fd';
            textColor = '#1976d2';
          } else if (status === 'Pending') {
            color = '#c8e6c9';
            textColor = '#388e3c';
          } else if (status === 'Inactive') {
            color = '#f5f5f5';
            textColor = '#616161';
          } else if (status === 'In Progress') {
            color = '#fff9c4';
            textColor = '#f57f17';
          } else if (status === 'Blocked') {
            color = '#ffcdd2';
            textColor = '#c62828';
          } else if (status === 'In Review') {
            color = '#e1bee7';
            textColor = '#7b1fa2';
          }
          
          return `<span style="background-color: ${color}; color: ${textColor}; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">${status}</span>`;
        }
      }] : []),
      // Add remaining fields
      ...Array.from(fieldNames)
        .filter(field => !['User Name', 'Profile Photo', 'Role', 'Status'].includes(field))
        .map(field => ({
          field: field,
          headerName: field,
          width: 180,
          cellRenderer: (params: any) => {
            const value = params.value;
            
            // Handle arrays
            if (Array.isArray(value)) {
              // Check if it's an image array
              if (value[0]?.url && value[0]?.thumbnails) {
                return `<img src="${value[0].thumbnails.small.url}" style="width: 30px; height: 30px; border-radius: 4px; object-fit: cover;" />`;
              }
              // Regular array
              return value.join(', ');
            }
            
            // Handle objects
            if (typeof value === 'object' && value !== null) {
              if (value.value !== undefined) {
                return value.value;
              }
              return JSON.stringify(value);
            }
            
            // Handle dates
            if (field.includes('Date') || field.includes('Login') || field.includes('Time')) {
              if (value) {
                const date = new Date(value);
                if (!isNaN(date.getTime())) {
                  return date.toLocaleDateString();
                }
              }
            }
            
            return value || '';
          }
        })),
      { 
        field: 'createdTime', 
        headerName: 'Created', 
        width: 150,
        valueFormatter: (params: any) => {
          if (params.value) {
            return new Date(params.value).toLocaleDateString();
          }
          return '';
        }
      }
    ];

    // Create grid data
    this.gridData = this.records.map(record => ({
      id: record.id,
      ...record.fields,
      createdTime: record.createdTime
    }));

    console.log('=== GRID SETUP COMPLETE ===');
    console.log('Grid data rows:', this.gridData.length);
    console.log('Grid data sample:', this.gridData[0]);
    console.log('Column definitions count:', this.columnDefs.length);
    console.log('Column definitions:', this.columnDefs);
  }

  syncData() {
    if (!this.selectedBase || !this.selectedTable) return;

    this.syncing = true;
    this.airtableService.syncData(this.selectedBase.id, this.selectedTable.id).subscribe({
      next: (response) => {
        this.snackBar.open(`Successfully synced ${response.totalRecords} records to MongoDB`, 'Close', {
          duration: 3000
        });
        this.syncing = false;
      },
      error: (error) => {
        console.error('Sync error:', error);
        this.snackBar.open('Error syncing data', 'Close', { duration: 3000 });
        this.syncing = false;
      }
    });
  }

  toggleCookiePanel() {
    this.showCookiePanel = !this.showCookiePanel;
  }

  setCookies() {
    if (!this.cookieUserId) {
      this.snackBar.open('User ID is required', 'Close', { duration: 3000 });
      return;
    }

    this.settingCookies = true;
    const data: any = { userId: this.cookieUserId };

    if (this.cookieString) {
      data.cookies = this.cookieString;
    } else if (this.cookieEmail && this.cookiePassword) {
      data.email = this.cookieEmail;
      data.password = this.cookiePassword;
      if (this.mfaCode) {
        data.mfaCode = this.mfaCode;
      }
    } else {
      this.snackBar.open('Provide either cookies or email/password', 'Close', { duration: 3000 });
      this.settingCookies = false;
      return;
    }

    this.scrapingService.setCookies(data).subscribe({
      next: (response) => {
        this.snackBar.open('Cookies saved successfully', 'Close', { duration: 3000 });
        this.cookieValidationStatus = { isValid: true, message: 'Cookies are valid' };
        this.settingCookies = false;
      },
      error: (error) => {
        this.snackBar.open('Failed to save cookies', 'Close', { duration: 3000 });
        this.cookieValidationStatus = { isValid: false, message: error.error?.message || 'Failed to save cookies' };
        this.settingCookies = false;
      }
    });
  }

  validateCookies() {
    if (!this.cookieUserId) {
      this.snackBar.open('User ID is required', 'Close', { duration: 3000 });
      return;
    }

    this.validating = true;
    this.scrapingService.validateCookies(this.cookieUserId).subscribe({
      next: (response) => {
        this.cookieValidationStatus = response;
        const message = response.isValid ? 'Cookies are valid and working!' : 'Cookies are invalid or expired';
        this.snackBar.open(message, 'Close', { duration: 3000 });
        this.validating = false;
      },
      error: (error) => {
        this.cookieValidationStatus = {
          isValid: false,
          message: error.error?.message || 'Error validating cookies'
        };
        this.snackBar.open('Error validating cookies', 'Close', { duration: 3000 });
        this.validating = false;
      }
    });
  }

  isFormValid(): boolean {
    if (!this.cookieUserId || this.cookieUserId.trim() === '') {
      return false;
    }
    
    // Check if either cookies OR email/password is provided
    const hasCookies = !!(this.cookieString && this.cookieString.trim() !== '');
    const hasCredentials = !!(this.cookieEmail && this.cookieEmail.trim() !== '' && 
                          this.cookiePassword && this.cookiePassword.trim() !== '');
    
    return hasCookies || hasCredentials;
  }

  clearCookieForm() {
    this.cookieUserId = '';
    this.cookieString = '';
    this.cookieEmail = '';
    this.cookiePassword = '';
    this.mfaCode = '';
    this.cookieValidationStatus = null;
    this.snackBar.open('Form cleared', 'Close', { duration: 2000 });
  }

  startBulkScraping() {
    if (!this.selectedBase || !this.selectedTable || !this.cookieUserId) {
      this.snackBar.open('Please select base, table and set cookies first', 'Close', { duration: 5000 });
      return;
    }

    // Check if records are loaded
    if (this.records.length === 0) {
      this.snackBar.open('No records loaded. Please wait for the table to load records first, then try again.', 'Close', { duration: 5000 });
      return;
    }

    this.scraping = true;
    this.scrapingProgress = null;

    console.log('Starting bulk scraping with:', {
      baseId: this.selectedBase.id,
      tableId: this.selectedTable.id,
      userId: this.cookieUserId,
      recordsInView: this.records.length
    });

    this.scrapingService.bulkFetchRevisionHistory({
      baseId: this.selectedBase.id,
      tableId: this.selectedTable.id,
      userId: this.cookieUserId,
      limit: 200
    }).subscribe({
      next: (response) => {
        console.log('Bulk scraping response:', response);
        this.scrapingProgress = response.results;
        
        if (response.results.successful > 0) {
          this.snackBar.open(
            `Scraping completed! Successful: ${response.results.successful}, Failed: ${response.results.failed}`, 
            'Close', 
            { duration: 5000 }
          );
        } else {
          this.snackBar.open(
            `Scraping completed but no records were successfully processed. Check console for details.`, 
            'Close', 
            { duration: 5000 }
          );
        }
        this.scraping = false;
      },
      error: (error) => {
        console.error('Bulk scraping error:', error);
        const errorMessage = error.error?.message || error.message || 'Unknown error';
        this.snackBar.open(
          'Scraping failed: ' + errorMessage, 
          'Close', 
          { duration: 7000 }
        );
        this.scraping = false;
        
        // Show additional info if it's a "no records" error
        if (errorMessage.includes('No records found')) {
          setTimeout(() => {
            this.snackBar.open(
              'Tip: Make sure the table has loaded records in the grid below before scraping', 
              'Close', 
              { duration: 5000 }
            );
          }, 1000);
        }
      }
    });
  }

  logout() {
    this.authService.logout().subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        console.error('Logout error:', error);
        this.router.navigate(['/']);
      }
    });
  }
}
