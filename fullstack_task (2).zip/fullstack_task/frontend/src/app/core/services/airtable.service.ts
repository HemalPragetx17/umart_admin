import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AirtableBase, AirtableTable, PaginatedRecords } from '../models/airtable.model';

@Injectable({
  providedIn: 'root'
})
export class AirtableService {
  private http = inject(HttpClient);
  private apiUrl = environment.apiUrl;

  getBases(): Observable<{ bases: AirtableBase[] }> {
    return this.http.get<{ bases: AirtableBase[] }>(`${this.apiUrl}/airtable/bases`);
  }

  getTables(baseId: string): Observable<{ tables: AirtableTable[] }> {
    return this.http.get<{ tables: AirtableTable[] }>(`${this.apiUrl}/airtable/bases/${baseId}/tables`);
  }

  getRecords(baseId: string, tableId: string, offset?: string, pageSize: number = 100): Observable<PaginatedRecords> {
    let params = new HttpParams().set('pageSize', pageSize.toString());
    if (offset) {
      params = params.set('offset', offset);
    }
    return this.http.get<PaginatedRecords>(
      `${this.apiUrl}/airtable/bases/${baseId}/tables/${tableId}/records`,
      { params }
    );
  }

  syncData(baseId: string, tableId: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/airtable/sync`, { baseId, tableId });
  }

  getUsers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/airtable/users`);
  }
}
