import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { 
  CookieData, 
  CookieValidation, 
  RevisionHistory, 
  BulkFetchRequest,
  BulkFetchResult 
} from '../models/scraping.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ScrapingService {
  private http = inject(HttpClient);
  private apiUrl = `${environment.apiUrl}/scraping`;

  setCookies(data: CookieData): Observable<any> {
    return this.http.post(`${this.apiUrl}/cookies`, data);
  }

  validateCookies(userId: string): Observable<CookieValidation> {
    return this.http.get<CookieValidation>(`${this.apiUrl}/cookies/${userId}/validate`);
  }

  fetchRevisionHistory(baseId: string, tableId: string, recordId: string, userId: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/revision-history/${baseId}/${tableId}/${recordId}`, {
      params: { userId }
    });
  }

  bulkFetchRevisionHistory(request: BulkFetchRequest): Observable<{ message: string, results: BulkFetchResult }> {
    return this.http.post<{ message: string, results: BulkFetchResult }>(
      `${this.apiUrl}/revision-history/bulk`, 
      request
    );
  }

  getRevisionHistory(recordId: string): Observable<RevisionHistory> {
    return this.http.get<RevisionHistory>(`${this.apiUrl}/revision-history/record/${recordId}`);
  }
}
