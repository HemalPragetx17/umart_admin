export interface CookieData {
  userId: string;
  cookies?: string;
  email?: string;
  password?: string;
  mfaCode?: string;
}

export interface CookieValidation {
  isValid: boolean;
  message?: string;
  lastValidated?: Date;
}

export interface RevisionHistoryChange {
  timestamp: Date;
  user: string;
  changeType: 'assignee' | 'status' | 'other';
  field: string;
  oldValue?: string;
  newValue?: string;
  rawHtml?: string;
}

export interface RevisionHistory {
  airtableRecordId: string;
  baseId: string;
  tableId: string;
  changes: RevisionHistoryChange[];
  lastScraped: Date;
}

export interface BulkFetchRequest {
  baseId: string;
  tableId: string;
  userId: string;
  limit?: number;
}

export interface BulkFetchResult {
  total: number;
  processed: number;
  successful: number;
  failed: number;
  errors: Array<{
    recordId: string;
    error: string;
  }>;
}
