export interface AirtableBase {
  id: string;
  name: string;
  permissionLevel: string;
}

export interface AirtableTable {
  id: string;
  name: string;
  primaryFieldId: string;
  fields: AirtableField[];
}

export interface AirtableField {
  id: string;
  name: string;
  type: string;
}

export interface AirtableRecord {
  id: string;
  fields: any;
  createdTime: string;
}

export interface PaginatedRecords {
  records: AirtableRecord[];
  offset?: string;
  hasMore: boolean;
}

export interface AuthStatus {
  authenticated: boolean;
  userId?: string;
  expiresAt?: Date;
}
