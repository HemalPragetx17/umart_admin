# Airtable Revision History Scraping - Implementation Guide

## Part 2: Custom Scraping Method for Revision History

### Overview
This implementation provides a robust scraping system to fetch Airtable revision history focusing on **Assignee** and **Status** changes.

## Features Implemented

### 1. **Cookie Management System**
- ✅ Automatic cookie retrieval with MFA support
- ✅ Cookie validation mechanism
- ✅ Secure cookie storage in MongoDB
- ✅ Cookie expiration tracking

### 2. **Revision History Scraping**
- ✅ HTML parsing from `/readRowActivitiesAndComments` endpoint
- ✅ Extraction of Assignee changes
- ✅ Extraction of Status changes
- ✅ Timestamp parsing
- ✅ User attribution

### 3. **Database Storage**
- ✅ `RevisionHistory` MongoDB collection
- ✅ `AirtableCookie` MongoDB collection for cookie management
- ✅ Optimized indexes for fast queries

### 4. **API Endpoints**

#### Cookie Management
```
POST /api/scraping/cookies
- Set cookies manually or via login with MFA
- Body: { userId, cookies?, email?, password?, mfaCode? }

GET /api/scraping/cookies/:userId/validate
- Validate if cookies are still valid
```

#### Revision History
```
GET /api/scraping/revision-history/:baseId/:tableId/:recordId?userId=xxx
- Fetch revision history for a single record

POST /api/scraping/revision-history/bulk
- Bulk fetch for up to 200+ pages
- Body: { baseId, tableId, userId, limit: 200 }

GET /api/scraping/revision-history/record/:recordId
- Get stored revision history from database
```

## How to Use

### Step 1: Set Cookies

**Option A: Using Browser Cookies (Recommended)**
1. Login to Airtable in your browser
2. Open Developer Tools (F12)
3. Go to Application → Cookies
4. Copy all cookie values
5. Use the API:
```bash
curl -X POST http://localhost:3000/api/scraping/cookies \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "user123",
    "cookies": "your_cookie_string_here"
  }'
```

**Option B: Login with Credentials + MFA**
```bash
curl -X POST http://localhost:3000/api/scraping/cookies \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "user123",
    "email": "your@email.com",
    "password": "yourpassword",
    "mfaCode": "123456"
  }'
```

### Step 2: Validate Cookies
```bash
curl http://localhost:3000/api/scraping/cookies/user123/validate
```

### Step 3: Fetch Revision History

**Single Record:**
```bash
curl "http://localhost:3000/api/scraping/revision-history/appXXX/tblYYY/recZZZ?userId=user123"
```

**Bulk Fetch (200+ records):**
```bash
curl -X POST http://localhost:3000/api/scraping/revision-history/bulk \
  -H "Content-Type: application/json" \
  -d '{
    "baseId": "appXXX",
    "tableId": "tblYYY",
    "userId": "user123",
    "limit": 200
  }'
```

### Step 4: Retrieve Stored History
```bash
curl http://localhost:3000/api/scraping/revision-history/record/recZZZ
```

## Frontend Usage

The dashboard includes a "Cookie Setup" button that provides:

1. **Cookie Input Form**
   - Manual cookie paste
   - OR Email/Password/MFA login
   
2. **Cookie Validation**
   - Real-time validation
   - Status indicators

3. **Bulk Scraping Button**
   - "Fetch Revision History" button (appears after selecting base/table)
   - Shows progress during scraping
   - Displays success/failure counts

## Database Schema

### RevisionHistory Collection
```javascript
{
  airtableRecordId: String,
  baseId: String,
  tableId: String,
  changes: [{
    timestamp: Date,
    user: String,
    changeType: 'assignee' | 'status' | 'other',
    field: String,
    oldValue: String,
    newValue: String,
    rawHtml: String
  }],
  lastScraped: Date
}
```

### AirtableCookie Collection
```javascript
{
  userId: String,
  cookies: String,
  csrfToken: String,
  expiresAt: Date,
  isValid: Boolean,
  lastValidated: Date
}
```

## Important Notes

### Cookie Validation
- Cookies are automatically validated before each scraping operation
- If cookies expire (401/403 response), you'll need to refresh them
- Cookie validation status is stored in the database

### Rate Limiting
- Bulk scraping processes in batches of 10 records
- 1-second delay between batches to avoid overwhelming Airtable
- Suitable for 200+ pages as requested

### Error Handling
- Individual record failures don't stop bulk operations
- All errors are logged with record IDs
- Detailed error messages returned in API responses

## Testing with 200+ Pages

```bash
# First, ensure you have pages in the database
curl http://localhost:3000/api/airtable/bases/:baseId/tables/:tableId/records

# Then run bulk scraping
curl -X POST http://localhost:3000/api/scraping/revision-history/bulk \
  -H "Content-Type: application/json" \
  -d '{
    "baseId": "your_base_id",
    "tableId": "your_table_id",
    "userId": "user123",
    "limit": 200
  }'
```

## Monitoring Progress

The bulk scraping endpoint returns:
```json
{
  "message": "Bulk fetch completed",
  "results": {
    "total": 200,
    "processed": 200,
    "successful": 198,
    "failed": 2,
    "errors": [
      {
        "recordId": "recXXX",
        "error": "Cookies expired or invalid"
      }
    ]
  }
}
```

## Security Considerations

1. **Cookie Storage**: Cookies are encrypted in MongoDB
2. **Authentication**: All scraping endpoints require authentication
3. **User Isolation**: Each user has their own cookie set
4. **Expiration**: Cookies automatically expire after 30 days
5. **Validation**: Cookies are validated before use

## Files Created

**Backend:**
- `models/RevisionHistory.model.js`
- `models/AirtableCookie.model.js`
- `services/cookieManager.js`
- `services/revisionHistoryParser.js`
- `controllers/scraping.controller.js`
- `routes/scraping.routes.js`

**Frontend:**
- `core/models/scraping.model.ts`
- `core/services/scraping.service.ts`
- Dashboard component updated with cookie UI

## Next Steps

1. Test with your Airtable workspace
2. Verify cookie extraction works
3. Run bulk scraping on 200+ pages
4. Monitor the RevisionHistory collection in MongoDB
5. Adjust parsing logic if needed for your specific Airtable structure

## Troubleshooting

**Cookies Not Working:**
- Ensure you're logged into Airtable in the same browser
- Check cookie expiration dates
- Try re-authenticating with MFA

**No Changes Found:**
- The HTML structure may vary - check `rawHtml` field
- Adjust parser regex patterns in `revisionHistoryParser.js`
- Verify the `/readRowActivitiesAndComments` endpoint URL format

**Rate Limiting:**
- Increase delay between batches in `scraping.controller.js`
- Reduce batch size from 10 to 5
